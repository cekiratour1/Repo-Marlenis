from django.shortcuts import render, redirect
from API.functions.dashboard.session import Session

class Login():
    def index(request):
        if request.method == 'GET':
            if Session.auth(request):
                return redirect('HomeIndex')

            return render(request, 'login/index.html')
        else:
            return Session.login(request)

    def logout(request):
        return Session.close(request)
            