$(document).ready(main);
var lstPrivilegios = null;
var privilegios = {};
var isEditing = false;
var item = {};
var accion = null;
var btnname = 'Guardar';
let blockBTN = false;

function main() {
    try {
        recargaPrivilegios();
        cargaVistas();
        reiniciarMultiSelect();
        //--
        $('#btnCNuevo').on('click', function () {
            txtCodRol.disabled = btnCreaPrivilegio.disabled = blockBTN;
            limpiarCampos('dvPrivilegios');
            reiniciarMultiSelect();
            btnname = "Guardar";
            $("#btnCreaPrivilegio").text(btnname);
            isEditing = false;
            $('#modalCRUD').modal('show');
        });
        //--
        $('#btnCreaPrivilegio').on('click', function () {
            if (validarDiv('formPrivilegios')) {
                if (isEditing) {
                    btnname = "Actualizar";
                    $("#btnCreaPrivilegio").text(btnname);
                    actualizaPrivilegios(item);
                } else {
                    btnname = "Guardar";
                    $("#btnCreaPrivilegio").text(btnname);
                    crearPrivilegios();
                }
                recargaPrivilegios();
                $('#modalCRUD').modal('hide');
            }
        });
        //--
        $('#lstPrivilegios tbody').on('click', 'tr td img', function () {
            accion = $(this).prop('id');
            item = lstPrivilegios.row($(this).parent().parent()).data();

            reiniciarMultiSelect();

            txtCodRol.appendChild(new Option(item.nombre, item.cod_rol, true, true));

            Object.keys(item.privilegios).forEach((cod_menu) => {
                $(txtCodMenu).multiselect('select', cod_menu);
            });

            txtCodRol.disabled = true;
            txtCodRol.appendChild(new Option())

            isEditing = item.cod_rol != null && item.cod_rol > 0;
            if (accion == 'delete') {
                $.alert.open('confirm', 'Confirmar', "¿Esta seguro que quiere eliminar este registro?", (button) => {
                    if (button == 'yes') {
                        borraPrivilegios(item);
                        recargaPrivilegios();
                        return true;
                    } else {
                        return;
                    }
                });
            } else {
                btnname = "Actualizar";
                btnCreaPrivilegio.disabled = false;
                $("#btnCreaPrivilegio").text(btnname);
                $('#modalCRUD').modal('show');
            }
        });
    } catch (e) {
        console.log(e)
        //debugger
    }
}

function recargaPrivilegios() {
    $("#lstPrivilegios").DataTable().destroy();
    cargaPrivilegios();
    cargaRoles();
}

function crearPrivilegios() {
    startLoading();//se agrego el cargando MP
    setTimeout(function () {
        var privilegio = new Object();
        privilegio.cod_usr = $(cod_usr).val();
        privilegio.cod_rol = $(txtCodRol).val();
        privilegio.fec_actu = moment().format('YYYY-MM-DD');

        for (cod_menu of $(txtCodMenu).val()) {
            privilegio.cod_menu = cod_menu;
            ejecutarAjax('/API/menu-rol-change/', 'POST', privilegio);
        }

        MuestraMensage('success', "Se guardo satisfactoriamente!");
        endLoading();
    }, 1000);
}

function actualizaPrivilegios(item) {
    startLoading();//se agrego el cargando MP
    var privilegio = {
        cod_rol: item.cod_rol,
        fec_actu: moment().format('YYYY-MM-DD'),
        cod_usr: item.cod_usr
    };
    setTimeout(function () {

        let cod_menus = $(txtCodMenu).val().map(Number);

        for (cod_menu of Object.keys(item.privilegios)) {
            if (cod_menus.includes(cod_menu)) {
                cod_menus = cod_menus.filter((cod) => cod != cod_menu);
            } else {
                ejecutarAjax('/API/menu-rol-change/' + item.privilegios[cod_menu] + '/', 'DELETE', null);
            }
        }

        for (cod_menu of cod_menus) {
            privilegio.cod_menu = cod_menu;
            ejecutarAjax('/API/menu-rol-change/', 'POST', privilegio);
        }

        MuestraMensage('success', "Se ha actualizado satisfactoriamente!");
        endLoading();
    }, 1000);
}

function borraPrivilegios(item) {
    startLoading();//se agrego el cargando MP
    setTimeout(function () {
        for (cod_menu_rol of Object.values(item.privilegios)) {
            ejecutarAjax(`/API/menu-rol-change/${cod_menu_rol}/`, 'DELETE', null);
        }
        MuestraMensage('success', "Se ha eliminado satisfactoriamente!");
        endLoading();
    }, 1000);
}

function cargaPrivilegios() {
    privilegios = {};
    var columnas = ["cod_rol", "nombre"];

    var request = ejecutarAjax('/API/menu-rol/', 'GET');
    request.forEach((privilegio) => {
        if (privilegios[privilegio.cod_rol.cod_rol] == undefined) {
            privilegios[privilegio.cod_rol.cod_rol] = {
                cod_rol: privilegio.cod_rol.cod_rol,
                nombre: privilegio.cod_rol.nombre,
                cod_usr: privilegio.cod_usr.cod_usuario,
                privilegios: {}
            };
        }

        privilegios[privilegio.cod_rol.cod_rol].privilegios[privilegio.cod_menu.cod_menu] = privilegio.cod_menu_rol;
    });
    privilegios = Object.values(privilegios);
    lstPrivilegios = cargaTabla("lstPrivilegios", privilegios, columnas);
    return true;
}

function cargaRoles() {
    var response = ejecutarAjax('/API/roles/', 'GET', null);
    txtCodRol.innerHTML = '';
    btnCreaPrivilegio.disabled = blockBTN = Object.keys(privilegios).length == Object.keys(response).length;

    $.each(response, function (id, name) {
        var row = privilegios.filter((item) => item.cod_rol == name.cod_rol);
        if (row.length == 0) {
            txtCodRol.appendChild(new Option(name.nombre, name.cod_rol, false, false))
        }
    });
}

function cargaVistas() {
    var response = ejecutarAjax('/API/menu/', 'GET', null);
    var optgroup = {};
    $.each(response, function (id, name) {
        if (name.cod_menu_padre != null) {
            if (optgroup[name.cod_menu_padre.cod_menu] == undefined) {
                var opt = document.createElement('optgroup');
                opt.label = name.cod_menu_padre.nombre_menu;
                optgroup[name.cod_menu_padre.cod_menu] = opt;
            }
            optgroup[name.cod_menu_padre.cod_menu].appendChild(new Option(name.nombre_menu, name.cod_menu, false, false))
        }
    });
    $.each(optgroup, (id, element) => {
        txtCodMenu.appendChild(element);
    })
}

function reiniciarMultiSelect() {
    $(txtCodMenu).multiselect('destroy');
    $(txtCodMenu).multiselect({ buttonWidth: '100%' });
    $(txtCodMenu).multiselect('clearSelection');
}