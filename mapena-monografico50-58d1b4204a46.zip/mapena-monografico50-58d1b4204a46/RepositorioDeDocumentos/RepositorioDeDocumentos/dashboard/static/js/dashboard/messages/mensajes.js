﻿//Mensajes para el usuario.
function MuestraMensage1(typeM, message, positionM) {

    notif({

        // success, error, warning, info
        type: typeM,

        // Default size
        width: 'all',
        height: 60,

        // Default position
        position: positionM, // left, center, right, bottom

        // Default autohide
        autohide: true,

        // Default msg
        msg: message,

        // Default opacity (Only Chrome, Firefox and Safari)
        opacity: 1,

        multiline: 0,
        fade: 0,
        bgcolor: "",
        color: "",
        timeout: 5000,

        // The z-index of the notification
        zindex: null,

        // The offset in pixels from the edge of the screen
        offset: 0,

        // Callback
        callback: null,

        clickable: false,

        append: false

    });
}
function MuestraMensage(type, message) {
    $.alert.open(type, message);
}
//
function MuestraMensage(type, message, script) {
  
    $.alert.open(type, message, function (button) {

        if (button == 'ok') {


            eval(script);
            return false;

        } else {
            return false;
        }
    });
    return false;
}

//Mensage para confirmar si continua o no una accion.
function MuestraMensageConfirmacion(message, botonid, script) {

    $.alert.open('confirm', message, function (button) {

        if (button === 'yes') {

            eval(script);
            return false;

        } else {
            return false;
        }
    });
    return false;
}

//Mensage para confirmar si continua o no una accion.
function MuestraMensageConfirmacion(message, botonid, script, botonNo, scriptNo) {

    $.alert.open('confirm', message, function (button) {

        if (button === 'yes') {

            eval(script);
            return false;

        } else if (button === 'no') {
            eval(scriptNo);
            return false;
        }
    });
    return false;
}

/**
Mensaje para confirmar si continua o no una accion.
al mismo se le puede agregar titulos asignar los nombres de botones segun su configuracion ejem. {ok:'OK', yes:"SI", etc }
MP  $.alert.open([type], [title], content, [buttons], [callback]);
*/
function MuestraMensageConfirmacion(message, botonid, script, botonNo, scriptNo, titulo, nombresBotones) {

    $.alert.open('confirm',titulo, message, nombresBotones, function (button) {

        if (button === 'yes') {

            eval(script);
            return false;

        } else if (button === 'no') {
            eval(scriptNo);
            return false;
        }
    });
    return false;
}
function MensageConfirmacion(message, scriptYes, scriptNo) {
    $.alert.open('confirm', message, function (button) {

        if (button === 'yes') {

            eval(scriptYes);
            return false;

        } else if (button === 'no') {
            if (scriptNo != null)
                eval(scriptNo);
            return false;
        }
    });
}

/*Control para darle un estilo a los controles que estan siendo validados, MP soteinfo*/
function ActualizaValidadores() {
    //for (var i = 0; i < Page_Validators.length; i++) {
    //    var val = Page_Validators[i];
    //    var ctrl = document.getElementById(val.controltovalidate);

    //    if (ctrl != null && ctrl.style != null) {
    //        if (!val.isvalid) {
    //            ctrl.classList.add("textbox_error");
    //        } else {
    //            ctrl.style.backgroundColor = '';
    //        }
    //    }
    //}
}

//Mensajes que aparecen en la parte derecha de la pantalla.
function MensajeLateral(type, mensaje, posicion) {

    toastr.options = {
        "closeButton": true,
        "debug": false,
        "newestOnTop": false,
        "progressBar": false,
        "positionClass": posicion,//"toast-bottom-right",
        "preventDuplicates": true,
        "onclick": null,
        "showDuration": "100",
        "hideDuration": "5000",
        "timeOut": "5000",
        "extendedTimeOut": "5000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }

    switch (type.toUpperCase()) {
        case "ERROR":
            toastr.error(mensaje);
            break;
        case "SUCCESS":
            toastr.success(mensaje);
            break;
        case "WARNING":
            toastr.warning(mensaje);
            break;
        case "INFO":
            toastr.info(mensaje);
            break;
        default:
            toastr.error("INGRESE TIPO DE MENSAJE VÁLIDO");
            break;
    }
}


function MensajeLateralScript(type, mensaje, posicion, script) {


    toastr.options = {
        "closeButton": true,
        "debug": false,
        "newestOnTop": false,
        "progressBar": false,
        "positionClass": posicion,//"toast-bottom-right",
        "preventDuplicates": true,
        "onclick": null,
        "showDuration": "100",
        "hideDuration": "5000",
        "timeOut": "5000",
        "extendedTimeOut": "5000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }

    switch (type.toUpperCase()) {
        case "ERROR":
            toastr.error(mensaje);
            break;
        case "SUCCESS":
            toastr.success(mensaje);
            break;
        case "WARNING":
            toastr.warning(mensaje);
            break;
        case "INFO":
            toastr.info(mensaje);
            break;
        default:
            toastr.error("INGRESE TIPO DE MENSAJE VÁLIDO");
            break;
    }

    eval(script);
    return false;

}

function mensajeImagen(modal, image, mensaje) {
    $(document).ready(function () {
        $(modal).modal('show');
        $('.modal-title').text(mensaje);
        $("#imagen").attr("src", image)
    })
}