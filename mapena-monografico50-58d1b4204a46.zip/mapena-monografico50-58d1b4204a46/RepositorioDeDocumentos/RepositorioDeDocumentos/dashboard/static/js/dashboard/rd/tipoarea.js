$(document).ready(main);
var lstTipoArea = null;
var isEditing = false;
var item = {};
var accion = null;
var btnname = 'Guardar';
function main() {

    try {
        recargaTipoArea();
        //--
        $("#btnCNuevo").on('click', function () {
            limpiarCampos('dvTipoArea');
            btnname = "Guardar";
            $("#btnCreaTipoArea").text(btnname);
            isEditing = false;
            $('#modalCRUD').modal('show');
        });
        //--
        $('#btnCreaTipoArea').on('click', function () {
            if (validarDiv('dvTipoArea')) {
                if (isEditing) {
                    btnname = "Actualizar";
                    $("#btnCreaTipoArea").text(btnname);
                    actualizaTipoArea(item);
                } else {
                    startLoading();
                    btnname = "Guardar";
                    $("#btnCreaTipoArea").text(btnname);
                    crearTipoArea();
                }
                recargaTipoArea();
                $('#modalCRUD').modal('hide');
            }
        });
        //--
        $('#lstTipoArea tbody').on('click', 'tr td img', function () {
            accion = $(this).prop('id');
            item = lstTipoArea.row($(this).parent().parent()).data();
            $(txtNomTipoArea).val(item.nom_tipoarea);
            if (item.cod_tipoarea != null && item.cod_tipoarea > 0) {
                isEditing = true;
            }
            if (accion == 'delete') {
                $.alert.open('confirm', 'Confirmar', "Esta seguro que quiere eliminar este registro?", (button) => {
                    if (button == 'yes') {
                        borraTipoArea(item);
                        return true;
                    } else {
                        return;
                    }

                });
            } else {
                btnname = "Actualizar";
                $("#btnCreaTipoArea").text(btnname);
                $('#modalCRUD').modal('show');
            }
        });


    } catch (e) {
        //debugger
    }
}

function recargaTipoArea() {
    $("#lstTipoArea").DataTable().destroy();
    cargaTipoArea();

}

function cargaTipoArea() {
    var area = new Object();
    var response = ejecutarAjax('/API/tipoareas/', 'GET', area);
    //console.log(response);
    var columnas = ["cod_tipoarea", "nom_tipoarea"];
    var columnasSize = ["5", "250", "10"];
    lstTipoArea = cargaTabla("lstTipoArea", response, columnas, columnasSize);
    return true;

}

function crearTipoArea() {
    if ($(txtNomTipoArea).val() === '') {
        MuestraMensage('warning', "Completa el campo.", "endLoading();");
    } else {
        var tipoarea = new Object();

        tipoarea.nom_tipoarea = $(txtNomTipoArea).val();
        tipoarea.cod_usr = $(cod_usr).val();
        tipoarea.fec_crea = moment().format('YYYY-MM-DD');
        tipoarea.fec_actu = moment().format('YYYY-MM-DD');
        tipoarea.mca_inh = 'N';

        var response = ejecutarAjax('/API/tipoareas/', 'POST', tipoarea);
        if (response != null) {
            MuestraMensage('success', "Se guardo sactifactoriamente!", "endLoading();");
        }
    }
}
function actualizaTipoArea(item) {

    item.fec_actu = moment().format('YYYY-MM-DD');
    item.nom_tipoarea = $(txtNomTipoArea).val();
    var response = ejecutarAjax('/API/tipoareas/' + item.cod_tipoarea + '/', 'PUT', item);
    if (response != null) {
        MuestraMensage('success', "Se actualizo sactifactoriamente!");
    }
}

function borraTipoArea(item) {
    var response = ejecutarAjax('/API/tipoareas/' + item.cod_tipoarea + '/', 'DELETE', item);
    if (response == null) {
        item = {};
        MuestraMensage('success', "Se eliminado sactifactoriamente!");
        recargaTipoArea();
    }

}
