$(document).ready(main);
var lstCategorias = null;
var isEditing = false;
var item = {} ;
var accion = null;
var btnname = 'Guardar';
function main() {
    
    try {
        recargaCategorias();
        //--
        $("#btnCNuevo").on('click', function () {
            limpiarCampos('dvCategorias');
            btnname = "Guardar";
            $("#btnCreacategoria").text(btnname);
            isEditing = false;
            $('#modalCRUD').modal('show');
        });
        //--
        $('#btnCreacategoria').on('click', function () {
            if (validarDiv('formcategoria')) {
                if (isEditing) {
                    btnname = "Actualizar";
                    $("#btnCreacategoria").text(btnname);
                    actualizaCategoria(item);
                } else {
                    btnname = "Guardar";
                    $("#btnCreacategoria").text(btnname);
                    crearCategoria();
                }
                recargaCategorias();
                $('#modalCRUD').modal('hide');
            }
        });
        //--
        $('#lstCategorias tbody').on('click', 'tr td img', function () {
            accion = $(this).prop('id');
            //console.log(accion);
            item = lstCategorias.row($(this).parent().parent()).data();
            $('#txtNomCategoria').val(item.nom_categoria);
            if (item.cod_categoria != null && item.cod_categoria > 0) {
                isEditing = true;
            }
            if (accion == 'delete') {
                $.alert.open('confirm', 'Confirmar', "Esta seguro que quiere eliminar este registro?", (button) => {
                    if (button == 'yes') {
                        borraCategoria(item);
                        return true;
                    } else {
                        return;
                    }

                });
            } else {
                btnname = "Actualizar";
                $("#btnCreacategoria").text(btnname);
                $('#modalCRUD').modal('show');
            }
        });


    } catch (e) {
        //debugger
    }
}

function recargaCategorias() {
    $("#lstCategorias").DataTable().destroy();
    cargaCategorias();

}

function crearCategoria() {
    var categoria = new Object();
    categoria.cod_usr = $(cod_usr).val();
    categoria.nom_categoria = $('#txtNomCategoria').val();
    categoria.mca_inh = 'N';
    categoria.fec_actu = moment().format('YYYY-MM-DD');
    var response = ejecutarAjax('/API/categorias/', 'POST', categoria);
    if (response != null) {
        MuestraMensage('success', "Se guardo sactifactoriamente!");
    }
}
function actualizaCategoria(item) {

    item.fec_actu = moment().format('YYYY-MM-DD');
    item.nom_categoria = $('#txtNomCategoria').val();
    var response = ejecutarAjax('/API/categorias/' + item.cod_categoria + '/', 'PUT', item);
    if (response != null) {
        item = {};
        MuestraMensage('success', "Se actualizo sactifactoriamente!");
    }
}

function borraCategoria(item) {
    var response = ejecutarAjax('/API/categorias/' + item.cod_categoria + '/', 'DELETE', null);
    //console.log(response);
    if (response == null) {
        item = {};
        MuestraMensage('success', "Se eliminado sactifactoriamente!");
        recargaCategorias();
    }

}

function cargaCategorias() {
    var categoria = new Object();
    var response = ejecutarAjax('/API/categorias/', 'GET', categoria);
    var columnas = ["cod_categoria", "nom_categoria"];

    lstCategorias = cargaTabla("lstCategorias", response, columnas);
       /*$('#lstCategorias').DataTable({
        responsive: true,
        paging: true,
        searching: true,
        destroy: true,
        "aaData": response,
        "columns": [{ "data": "cod_categoria" },
                    { "data": "nom_categoria" },
            {
                "defaultContent": '<img src="../../static/img/icons/edit.png" id="edit" style="cursor:pointer;margin-right:25px" />' +
                                  '<img src="../../static/img/icons/delete.png" id="delete" style="cursor:pointer" />'
            },

        ],
        "columnDefs": [
            { "width": "5px", "targets": 0 },
            { "width": "450px", "targets": 1 },
            { "width": "5px", "targets": 2 }

        ]
    });*/
    return true;

}