$(document).ready(main);

function main() {
   
    try {
        $('#btnCreaFacultad').on('click', function () {
            crearF();
        });
    } catch (e) {
        //debugger
    }
}


function editarF() {
    var name = document.getElementById('name');
    var cod = document.getElementById('cod');
    var nombre = document.getElementById('txtNombre');
    var codigo = document.getElementById('txtCod');
    var btn = document.getElementById('btnsubmit');
    var btnCancelar = document.getElementById('btnCancelar');

    var n = name.getAttribute('value');
    var c = cod.getAttribute('value');

    codigo.setAttribute('value', c);
    nombre.setAttribute('value', n);
    btn.setAttribute('value', 'Actualizar');
    btnCancelar.removeAttribute('hidden');
}
function crearF() {
    var facultad = new Object();

    facultad.cod_usr = $(cod_usr).val();
    facultad.nombre = $('#txtNombre').val();
    facultad.mca_inh = 'N';

    //console.log(facultad);
    var responde = ejecutarAjax('/API/crearfacultad/','POST', facultad);
    //var btnCancelar = document.getElementById('btnCancelar');
    //btn.setAttribute('value', 'Guardar');
    //console.log(responde);
    btnCancelar.setAttribute('hidden', 'hidden');
}

function actualizarF() {
    var name = document.getElementById('name');
    var cod = document.getElementById('cod');
    var nombre = document.getElementById('txtNombre');
    var codigo = document.getElementById('txtCod');
    var btn = document.getElementById('btnsubmit');
    var btnCancelar = document.getElementById('btnCancelar');

    var n = nombre.getAttribute('value');
    var c = codigo.getAttribute('value');

    name.setAttribute('name', n);
    cod.setAttribute('name', c);
    btn.setAttribute('value', 'Guardar');
    btnCancelar.setAttribute('hidden', 'hidden');
}
function cancelar() {
    var nombre = document.getElementById('txtNombre');
    var codigo = document.getElementById('txtCod');
    var btn = document.getElementById('btnsubmit');
    var btnCancelar = document.getElementById('btnCancelar');

    nombre.setAttribute('value', '');
    codigo.setAttribute('value', '');
    btn.setAttribute('value', 'Guardar');
    btnCancelar.setAttribute('hidden', 'hidden');
}

