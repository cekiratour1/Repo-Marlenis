$(document).ready(main);
var lstRoles = null;
var isEditing = false;
var item = {};
var accion = null;
var btnname = 'Guardar';
function main() {

    try {
        recargaRoles();
        //--
        $('#btnCNuevo').on('click', function () {
            limpiarCampos('dvRoles');
            btnname = "Guardar";
            $("#btnCreaRoles").text(btnname);
            isEditing = false;
            $('#modalCRUD').modal('show');
        });
        //--
        $('#btnCreaRoles').on('click', function () {
            if (validarDiv('formRoles')) {
                if (isEditing) {
                    btnname = "Actualizar";
                    $("#btnCreaRoles").text(btnname);
                    actualizaRoles(item);
                } else {
                    btnname = "Guardar";
                    $("#btnCreaRoles").text(btnname);
                    crearRoles();
                }
                recargaRoles();
                $('#modalCRUD').modal('hide');
            }
        });
        //--
        $('#lstRoles tbody').on('click', 'tr td img', function () {
            accion = $(this).prop('id');
            console.log(accion);
            item = lstRoles.row($(this).parent().parent()).data();
            $('#txtNomRoles').val(item.nombre);
            $("#txtMcaAprueba").val(item.mca_aprueba);
            if (item.cod_rol != null && item.cod_rol > 0) {
                isEditing = true;
            }
            if (accion == 'delete') {
                $.alert.open('confirm', 'Confirmar', "Esta seguro que quiere eliminar este registro?", (button) => {
                    if (button == 'yes') {
                        borraRoles(item);
                        return true;
                    } else {
                        return;
                    }

                });
            } else {
                btnname = "Actualizar";
                $("#btnCreaRoles").text(btnname);
                $('#modalCRUD').modal('show');
            }
        });


    } catch (e) {
        //debugger
    }
}

function recargaRoles() {
    $("#lstRoles").DataTable().destroy();
    cargaRoles();

}

function crearRoles() {
    var Roles = new Object();
    Roles.cod_usr = $(cod_usr).val();
    Roles.nombre = $('#txtNomRoles').val();
    Roles.mca_aprueba = $("#txtMcaAprueba").val();
    Roles.mca_inh = 'N';
    Roles.fec_actu = moment().format('YYYY-MM-DD');
    var response = ejecutarAjax('/API/roles/', 'POST', Roles);
    if (response != null) {
        MuestraMensage('success', "Se guardo sactifactoriamente!");
    }
}
function actualizaRoles(item) {

    item.fec_actu = moment().format('YYYY-MM-DD');
    item.nombre = $('#txtNomRoles').val();
    item.mca_aprueba = $("#txtMcaAprueba").val();
    var response = ejecutarAjax('/API/roles/' + item.cod_rol + '/', 'PUT', item);
    if (response != null) {
        item = {};
        MuestraMensage('success', "Se actualizo sactifactoriamente!");
    }
}

function borraRoles(item) {
    var response = ejecutarAjax('/API/roles/' + item.cod_rol + '/', 'DELETE', null);
    console.log(response);
    if (response == null) {
        item = {};
        MuestraMensage('success', "Se eliminado sactifactoriamente!");
        recargaRoles();
    }

}

function cargaRoles() {
    var Roles = new Object();
    var response = ejecutarAjax('/API/roles/', 'GET', Roles);
    var columnas = ["cod_rol", "nombre"];

    lstRoles = cargaTabla("lstRoles", response, columnas);
    /*$('#lstRoles').DataTable({
    responsive: true,
    paging: true,
    searching: true,
    destroy: true,
    "aaData": response,
    "columns": [{ "data": "cod_Roles" },
                { "data": "nom_Roles" },
        {
            "defaultContent": '<img src="../../static/img/icons/edit.png" id="edit" style="cursor:pointer;margin-right:25px" />' +
                              '<img src="../../static/img/icons/delete.png" id="delete" style="cursor:pointer" />'
        },

    ],
    "columnDefs": [
        { "width": "5px", "targets": 0 },
        { "width": "450px", "targets": 1 },
        { "width": "5px", "targets": 2 }

    ]
});*/
    return true;

}
