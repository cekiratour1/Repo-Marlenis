$(document).ready(main);
var lstUsuarios = null;
var isEditing = false;
var item = [];
var accion = null;
var btnname = 'Guardar';

function main() {
    try {
        recargaUsuarios();
        $("#btnCNuevo").on('click', function () {
            limpiarCampos('dvUsuarios');
            btnname = "Guardar";
            $("#btnCreausuario").text(btnname);
            isEditing = false;
            $('#modalCRUD').modal('show');
        });
        $('#btnCreausuario').on('click', function () {
            if (validarDiv('dvUsuarios')) {
                let request = true;

                if (isEditing) {
                    $("#btnCreausuario").text("Actualizar");
                    request = actualizaUsuario(item);
                } else {
                    $("#btnCreausuario").text("Guardar");
                    request = crearUsuario();
                }

                if (request) {
                    recargaUsuarios();
                    $('#modalCRUD').modal('hide');
                }
            }

        });
        $('#lstUsuarios tbody').on('click', 'tr td img', function () {
            accion = $(this).prop('id');
            item = lstUsuarios.row($(this).parent().parent()).data();
            $(txtNombre).val(item.nombre);
            $(txtApellido).val(item.apellido);
            $(txtUsuario).val(item.usuario);
            $(txtEmail).val(item.correo);

            isEditing = item.cod_usuario != null && item.cod_usuario > 0;
            if (accion == 'delete') {
                $.alert.open('confirm', 'Confirmar', "Esta seguro que quiere eliminar este registro?", (button) => {
                    if (button == 'yes') {
                        borrausuario(item);
                        return true;
                    } else {
                        return;
                    }
                });
            } else {
                $(btnCreausuario).text("Actualizar");
                $(modalCRUD).modal('show');
            }
        });
    } catch (e) {
        //debugger
    }
}

function recargaUsuarios() {
    usuarios = [];
    $("#lstUsuarios").DataTable().destroy();
    cargaUsuarios();
}

function existeUsuario(nombreUsuario) {
    var usuarios = ejecutarAjax('/API/usuario/', 'GET')
    for (usuario of usuarios) {
        if (usuario.usuario.toLowerCase() === nombreUsuario.toLowerCase()) {
            return true;
        }
    }
    return false;
}

function crearUsuario() {
    if ($(txtContrasena).val() !== $(txtRContrasena).val()) {
        MuestraMensage('warning', "Las claves no coinciden");
    } else if ($(txtContrasena).val().length < 6) {
        MuestraMensage('warning', "La longitud de la contrase&ntilde;a es menor a 6.");
    } else if (existeUsuario($(txtUsuario).val())) {
        MuestraMensage('warning', "El usuario ingresado existe.");
    } else {
        var usuario = new Object();
        usuario.nombre = $(txtNombre).val()
        usuario.apellido = $(txtApellido).val()
        usuario.usuario = $(txtUsuario).val()
        usuario.contrasena = Encrypt.text($(txtContrasena).val())
        usuario.correo = $(txtEmail).val()
        usuario.mca_inh = 'N'

        var response = ejecutarAjax('/API/usuario/', 'POST', usuario);
        if (response != null) {
            MuestraMensage('success', "Se guardo sactifactoriamente!");
        }
        return true;
    }
    return false;
}

function actualizaUsuario(item) {
    if (existeUsuario($(txtUsuario).val()) && $(txtUsuario).val() !== item.usuario) {
        MuestraMensage('warning', "El usuario ingresado existe.");
    } else if ($(txtContrasena).val().length !== 0 && $(txtContrasena).val().length < 6) {
        MuestraMensage('warning', "La longitud de la contrase&ntilde;a es menor a 6.");
    } else if ($(txtContrasena).val().length !== 0 && $(txtContrasena).val().length >= 6 && $(txtContrasena).val() !== $(txtRContrasena).val()) {
        MuestraMensage('warning', "Las claves no coinciden");
    } else {
        item.nombre = $(txtNombre).val();
        item.apellido = $(txtApellido).val();
        item.usuario = $(txtUsuario).val();
        item.correo = $(txtEmail).val();
        item.fec_actu = moment().format('YYYY-MM-DD');
        if($(txtContrasena).val().length > 0){
            item.contrasena = Encrypt.text($(txtContrasena).val());
        }

        var response = ejecutarAjax(`/API/usuario/${item.cod_usuario}/`, 'PUT', item);
        if (response != null) {
            item = [];
            MuestraMensage('success', "Se actualizo sactifactoriamente!");
        }
        return true;
    }
    return false;
}

function borrausuario(item) {
    item.fec_actu = moment().format('YYYY-MM-DD');
    item.mca_inh = 'S';
    var response = ejecutarAjax(`/API/usuario/${item.cod_usuario}/`, 'PUT', item);

    if (response != null) {
        item = [];
        MuestraMensage('success', "Se eliminado sactifactoriamente!");
        recargaUsuarios();
    }
}

function cargaUsuarios() {
    var usuario = new Object();
    var response = ejecutarAjax('/API/usuario/', 'GET', usuario);
    lstUsuarios = $('#lstUsuarios').DataTable({
        responsive: true,
        paging: true,
        searching: true,
        destroy: true,
        "aaData": response,
        "columns": [
        { "data": "cod_usuario" },
        { "data": "nombre" },
        { "data": "apellido" },
        { "data": "usuario" },
        { "data": "correo" },
        { "defaultContent": '<img src="../../static/img/icons/edit.png" id="edit" style="cursor:pointer;margin-right:25px" /><img src="../../static/img/icons/delete.png" id="delete" style="cursor:pointer" />' },

        ],
        "columnDefs": [
            { "width": "5px", "targets": 0 },
            { "width": "30px", "targets": 1 },
            { "width": "30px", "targets": 2 },
            { "width": "30px", "targets": 3 },
            { "width": "50px", "targets": 4 },
            { "width": "5px", "targets": 5 }
        ]
    });

    return true;
}