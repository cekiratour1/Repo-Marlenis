$(document).ready(main);
var lstFacultades = null;
var isEditing = false;
var item = {};
var accion = null;
var btnname = 'Guardar';
function main() {

    try {
        recargaFacultades();
        //--
        $('#btnCNuevo').on('click', function () {
            limpiarCampos('dvFacultades');
            btnname = "Guardar";
            $("#btnCreaFacultades").text(btnname);
            isEditing = false;
            $('#modalCRUD').modal('show');
        });
        //--
        $('#btnCreaFacultades').on('click', function () {
            if (validarDiv('formfacultades')) {
                if (isEditing) {
                    btnname = "Actualizar";
                    $("#btnCreaFacultades").text(btnname);
                    actualizaFacultades(item);
                } else {
                    btnname = "Guardar";
                    $("#btnCreaFacultades").text(btnname);
                    crearFacultades();
                }
                recargaFacultades();
                $('#modalCRUD').modal('hide');
            }
        });
        //--
        $('#lstFacultades tbody').on('click', 'tr td img', function () {
            accion = $(this).prop('id');
            //console.log(accion);
            item = lstFacultades.row($(this).parent().parent()).data();
            $('#txtNomFacultades').val(item.nombre);
            if (item.cod_facultad != null && item.cod_facultad > 0) {
                isEditing = true;
            }
            if (accion == 'delete') {
                $.alert.open('confirm', 'Confirmar', "Esta seguro que quiere eliminar este registro?", (button) => {
                    if (button == 'yes') {
                        borraFacultades(item);
                        return true;
                    } else {
                        return;
                    }

                });
            } else {
                btnname = "Actualizar";
                $("#btnCreaFacultades").text(btnname);
                $('#modalCRUD').modal('show');
            }
        });


    } catch (e) {
        //debugger
    }
}

function recargaFacultades() {
    $("#lstFacultades").DataTable().destroy();
    cargaFacultades();

}

function crearFacultades() {
    var Facultades = new Object();
    Facultades.cod_usr = $(cod_usr).val();
    Facultades.nombre = $('#txtNomFacultades').val();
    Facultades.mca_inh = 'N';
    Facultades.fec_actu = moment().format('YYYY-MM-DD');
    var response = ejecutarAjax('/API/crearfacultad/', 'POST', Facultades);
    if (response != null) {
        MuestraMensage('success', "Se guardo sactifactoriamente!");
    }
}
function actualizaFacultades(item) {

    item.fec_actu = moment().format('YYYY-MM-DD');
    item.nombre = $('#txtNomFacultades').val();
    var response = ejecutarAjax('/API/crearfacultad/' + item.cod_facultad + '/', 'PUT', item);
    if (response != null) {
        item = {};
        MuestraMensage('success', "Se actualizo sactifactoriamente!");
    }
}

function borraFacultades(item) {
    var response = ejecutarAjax('/API/crearfacultad/' + item.cod_facultad + '/', 'DELETE', null);
    //console.log(response);
    if (response == null) {
        item = {};
        MuestraMensage('success', "Se eliminado sactifactoriamente!");
        recargaFacultades();
    }

}

function cargaFacultades() {
    var Facultades = new Object();
    var response = ejecutarAjax('/API/crearfacultad/', 'GET', Facultades);
    var columnas = ["cod_facultad", "nombre"];

    lstFacultades = cargaTabla("lstFacultades", response, columnas);
    /*$('#lstFacultades').DataTable({
    responsive: true,
    paging: true,
    searching: true,
    destroy: true,
    "aaData": response,
    "columns": [{ "data": "cod_Facultades" },
                { "data": "nom_Facultades" },
        {
            "defaultContent": '<img src="../../static/img/icons/edit.png" id="edit" style="cursor:pointer;margin-right:25px" />' +
                              '<img src="../../static/img/icons/delete.png" id="delete" style="cursor:pointer" />'
        },

    ],
    "columnDefs": [
        { "width": "5px", "targets": 0 },
        { "width": "450px", "targets": 1 },
        { "width": "5px", "targets": 2 }

    ]
});*/
    return true;

}