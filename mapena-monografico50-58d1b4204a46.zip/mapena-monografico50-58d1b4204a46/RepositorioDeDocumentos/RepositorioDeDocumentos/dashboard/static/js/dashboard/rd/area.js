$(document).ready(main);
var lstArea = null;
var isEditing = false;
var item = {};
var accion = null;
var btnname = 'Guardar';
function main() {

    try {
        recargaArea();
        cargaFacultades();
        cargaTipoArea();
        //--
        $("#btnCNuevo").on('click', function () {
            limpiarCampos('dvArea');
            btnname = "Guardar";
            $("#btnCreaArea").text(btnname);
            isEditing = false;
            $('#modalCRUD').modal('show');
        });
        //--
        $('#btnCreaArea').on('click', function () {
            if (validarDiv('formArea')) {
                if (isEditing) {
                    btnname = "Actualizar";
                    $("#btnCreaArea").text(btnname);
                    actualizaArea(item);
                } else {
                    startLoading();
                    //console.log("entre");
                    btnname = "Guardar";
                    $("#btnCreaArea").text(btnname);
                    crearArea();
                }
                recargaArea();
                $('#modalCRUD').modal('hide');
            }
        });
        //--
        $('#lstArea tbody').on('click', 'tr td img', function () {
            accion = $(this).prop('id');
            item = lstArea.row($(this).parent().parent()).data();
            $('#txtCodFacultad').val(item.cod_facultad.cod_facultad);
            $('#txtNomArea').val(item.nom_area);
            $('#txtCodTipoArea').val(item.cod_tipoarea.cod_tipoarea);
            if (item.cod_area != null && item.cod_area > 0) {
                isEditing = true;
            }
            if (accion == 'delete') {
                $.alert.open('confirm', 'Confirmar', "Esta seguro que quiere eliminar este registro?", (button) => {
                    if (button == 'yes') {
                        borraArea(item);
                        return true;
                    } else {
                        return;
                    }

                });
            } else {
                btnname = "Actualizar";
                $("#btnCreaArea").text(btnname);
                $('#modalCRUD').modal('show');
            }
        });


    } catch (e) {
        //debugger
    }
}

function recargaArea() {
    $("#lstArea").DataTable().destroy();
    cargaArea();

}

function cargaArea() {
    var area = new Object();
    var response = ejecutarAjax('/API/areaslist/', 'GET', area);
    var columnas = ["cod_area", "nom_area", 'cod_facultad.nombre', 'cod_tipoarea.nom_tipoarea'];
    var columnasSize = ["5", "250", "300", "50", "15"];
    lstArea = cargaTabla("lstArea", response, columnas, columnasSize);
    return true;

}

function crearArea() {
    var area = new Object();
    area.cod_usr = $(cod_usr).val();
    area.nom_area = $('#txtNomArea').val();
    area.cod_facultad = $('#txtCodFacultad').val();
    area.cod_tipoarea = $('#txtCodTipoArea').val();
    area.mca_inh = 'N';
    area.fec_actu = moment().format('YYYY-MM-DD');
    var response = ejecutarAjax('/API/areas/', 'POST', area);
    if (response != null) {
        MuestraMensage('success', "Se guardo sactifactoriamente!","endLoading();");
    }
}
function actualizaArea(item) {

    item.fec_actu = moment().format('YYYY-MM-DD');
    item.cod_facultad = $('#txtCodFacultad').val();
    item.nom_area = $('#txtNomArea').val();
    item.cod_tipoarea = $('#txtCodTipoArea').val();
    var response = ejecutarAjax('/API/areas/' + item.cod_area + '/', 'PUT', item);
    if (response != null) {
        MuestraMensage('success', "Se actualizo sactifactoriamente!");
    }
}

function borraArea(item) {
    var response = ejecutarAjax('/API/areas/' + item.cod_area + '/', 'DELETE', item);
    //console.log(response);
    if (response == null) {
        item = {};
        MuestraMensage('success', "Se eliminado sactifactoriamente!");
        recargaArea();
    }

}

function cargaFacultades() {
    var response = ejecutarAjax('/API/listfacultad/', 'GET', null);
    var $select = $('#txtCodFacultad');
    $select.append('<option value="">..Seleccione..</option>');
    $.each(response, function (id, name) {
        $select.append('<option value=' + name.cod_facultad + '>' + name.nombre + '</option>');
    });
}

function cargaTipoArea() {
    var response = ejecutarAjax('/API/tipoareas/', 'GET', null);
    var $select = $('#txtCodTipoArea');
    $select.append('<option value="">..Seleccione..</option>');
    $.each(response, function (id, name) {
        $select.append('<option value=' + name.cod_tipoarea + '>' + name.nom_tipoarea + '</option>');
    });
}