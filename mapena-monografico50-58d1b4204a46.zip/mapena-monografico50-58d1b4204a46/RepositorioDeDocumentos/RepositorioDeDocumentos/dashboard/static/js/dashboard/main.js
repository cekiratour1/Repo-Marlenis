
if ($("#hfusr").val() == null || $("#hfusr").val() == '') {
    window.location.href = "/login";
}
$(document).ready(function () {
    try{
        let __menu = loadMenu(JSON.parse($('#menu').val()));
        for(menu of __menu){
            dynamic_menu.appendChild(menu)
        }
    }catch (e){
        console.log(e)
    }
    jqueryPlugins();
});

$(window).ready(function () {

    $('#preloader').delay(400).fadeOut(1000);
    $('#overlay').delay(400).fadeOut(1000);

});
// LLamar a los plugins segun se necesiten de jquery
function jqueryPlugins() {
    $('#dataTable').DataTable();

    /*Validaciones*/
    $("#rd").validationEngine();


    $(".rd_validar").on("click", function () {
        return $('#rd').validationEngine('validate');
    });
    $(".rd_novalidar").on("click", function () {
        return $('#rd').validationEngine('detach');
    });
    $("[data-toggle]").on("click", function () {
        $("#rd").validationEngine();
    });

}

function createMenuParent(parent){
    var container = document.createElement('li');
    var nav_link = document.createElement('a');
    var icon = document.createElement('i');
    var title = document.createElement('span');
    var children = loadMenu(parent.children);

    container.className = 'nav-item';
    nav_link.className = 'nav-link collapsed';
    nav_link.href = parent.url.length > 0 ? parent.url : '#';
    nav_link.dataset.target = `#collapse_parent${parent.cod_menu}`;
    nav_link.dataset.toggle = "collapse";
    icon.className = parent.icon;
    title.innerText = parent.name;

    if(parent.icon.length > 0){
        nav_link.appendChild(icon);
    }

    nav_link.appendChild(title);
    container.appendChild(nav_link);

    var collapse = document.createElement('div');
    var inner_collapse = document.createElement('div');

    collapse.id = `collapse_parent${parent.cod_menu}`;
    collapse.className = 'collapse';
    collapse.dataset.parent = '#accordionSidebar';

    inner_collapse.className = 'bg-white py-2 collapse-inner rounded';
    for(child of children){
        inner_collapse.appendChild(child);
    }
    collapse.appendChild(inner_collapse)
    container.appendChild(collapse);

    return container;
}

function createSubMenuParent(parent){
    var container = document.createElement('div');
    var collapse = document.createElement('div');
    var collapse_item = document.createElement('a');
    var icon = document.createElement('i');
    var title = document.createElement('span');
    var children = loadMenu(parent.children);

    collapse_item.className = 'collapse-item collapsed bg-gray-200';
    collapse_item.href = '#';
    collapse_item.dataset.target = `#collapse_sub_parent_item${parent.cod_menu}`;
    collapse_item.dataset.toggle = 'collapse';
    icon.className = parent.icon;
    title.innerText = parent.name;

    if(parent.icon.length > 0){
        collapse_item.appendChild(icon);
    }

    collapse_item.appendChild(title)
    container.appendChild(collapse_item);

    collapse.className = 'collapse';
    collapse.id = `collapse_sub_parent_item${parent.cod_menu}`;

    for(element of children){
        collapse.appendChild(element);
    }

    console.log(children[0])

    container.appendChild(collapse);

    return container;
}

function createMenuOption(data){
    var link = document.createElement('a');
    var icon = document.createElement('i');
    var title = document.createElement('span');

    link.className = 'collapse-item';
    link.href = data.url.length > 0 ? data.url : '#';

    icon.className = data.icon;

    if(data.icon.length > 0){
        link.appendChild(icon);
    }

    title.innerText = data.name;
    link.appendChild(title);

    return link;
}

function loadMenu(main_menu){
    var elements = [];
    for(key in main_menu){
        if(Object.keys(main_menu[key].children).length > 0){
            if(main_menu[key].is_main){
                elements.push(createMenuParent(main_menu[key]));
            }else{
                elements.push(createSubMenuParent(main_menu[key]));
            }
        }else{
            let __option = createMenuOption(main_menu[key]);
            elements.push(__option)
        }
    }
    return elements;
}