$(document).ready(main);
var lstLibros = null;
var lstArchivos = null;
var isEditing = false;
var item = {};
var archivosTemp = [];
var tempBin_libro;
var tempBin_archivo;
var accion = null;
var btnname = 'Guardar';
var mcaAprueba;
var usrTemp;
function main() {
    try {
        CargaEstados();
        cargaLibros();
        cargaFacultades();
        cargaCategoria();
        //--
        $("#txtCodFacultad").on('change', function () {
            cargaAreas($(this).val());
        });
        //--
        $("#btnCNuevo").on('click', function () {
            limpiarCampos('dvLibros');
            limpiarCampos('dvArchivo');
            tempBin_libro = null;
            $("[id$='img2']").attr('src', "../../static/img/Sinimagen.gif");

            archivosTemp = [];
            cargaArchivo();
            btnname = "Guardar";
            $("#btnCreaLibros").text(btnname);
            isEditing = false;
            $('#modalCRUD').modal('show');
        });
        //--Agrega imagen en la cabecera.
        $("[id$='img2']").on("click", function () {
            $("[id$='fup2']").click();
        });

        //--
        $("#btnAdjuntarNuevo").on('click', function () {
            limpiarCampos('dvArchivo');
            cargaArchivo();

            if (archivosTemp.length < 3) {
                $('#modalCRUD').modal('hide');
                $('#modalArchivos').modal('show');
            } else {
                MuestraMensage('warning', "No puede adjuntar mas de 3 archivos.");
            }
        });
        //--
        $("#btnSalirAdjuntarArchivo").on('click', function () {
            $('#modalCRUD').modal('show');
            $('#modalArchivos').modal('hide');
        });

        //--
        $('#btnCreaLibros').on('click', function () {
            if (validarDiv('dvLibro')) {
                if (isEditing) {
                    btnname = "Actualizar";
                    $("#btnCreaLibros").text(btnname);
                    actualizaLibros(item);
                } else {
                    btnname = "Guardar";
                    $("#btnCreaLibros").text(btnname);
                    crearLibros();
                }

                $('#modalCRUD').modal('hide');
            }
        });
        //--
        $('#fArchivo').bs_dropzone({
            preview: true,
            accepted: ['pdf', 'doc', 'docx', 'html'],
            dropzoneTemplate: '<div class="bs-dropzone"><div class="bs-dropzone-area"></div><div class="bs-dropzone-message"></div><div class="bs-dropzone-preview mt-0"></div></div>',
            parentTemplate: '<div class="row ml-0 justify-content-center align-items-center"></div>',
            childTemplate: '<div class="col-4 col-md-3 pl-0"></div>',
            imageClass: 'img-fluid mt-3 rounded',
            language: {
                emptyText: 'Arrastre su Archivo o click para subirlo',
                dragText: 'Arrastre su Archivo',
                dropText: '_t_ Archivo(s)'
            },
        });
        const fileInput = document.getElementById('fArchivo')
        // This is for storing the base64 strings
        let myFiles = {}
        // if you expect files by default, make this disabled
        // we will wait until the last file being processed
        let isFilesReady = true

        fileInput.addEventListener('change', async (event) => {
            const files = event.srcElement.files;

            subirArchivo(event);

        });
        //--
        $("#btnAdjuntarArchivo").on('click', function (e) {
            adjuntarArhicvoTemp(item);
        });
        //--
        $('#lstLibros tbody').on('click', 'tr td img', function () {
            accion = $(this).prop('id');

            item = lstLibros.row($(this).parent().parent()).data();
            if (item.cod_libro != null && item.cod_libro > 0) {
                isEditing = true;
            }
            if (accion == 'delete') {
                $.alert.open('confirm', 'Confirmar', "Esta seguro que quiere eliminar este registro?", (button) => {
                    if (button == 'yes') {
                        borraLibros(item);
                        return true;
                    } else {
                        return;
                    }
                });
            } else {
                getLibro(item);
                btnname = "Actualizar";
                $("#btnCreaLibros").text(btnname);
                $('#modalCRUD').modal('show');
            }
        });
        $('#lstArchivos').on('click', 'tbody tr td img', function () {
            accion = $(this).prop('id');
            item = lstArchivos.row($(this).parent().parent()).data();
            if (item.cod_libro != null && item.cod_libro > 0) {
                isEditing = true;
            }
            if (accion == 'delete') {
                $.alert.open('confirm', 'Confirmar', "Esta seguro que quiere eliminar este registro?\n Este ser&aacute; eliminado directamente de documento", (button) => {
                    if (button == 'yes') {
                        borraArchivo(item);
                        return true;
                    } else {
                        return;
                    }
                });
            } else {
                //Accion para edicion.
            }
        });

    } catch (e) {
        console.log(e);
    }
}

function recargaLibros() {
    //$("#lstLibros").DataTable().destroy();
    //cargaLibros();
    //endLoading();
    window.location.href = '/dashboard/libros/';

}

function cargaLibros() {
    var libro = new Object();
    var response = ejecutarAjax('/API/libroslist/', 'GET', libro);
    var columnas = ["cod_libro", "cod_facultad.nombre", 'cod_area.nom_area', 'autor', 'titulo', 'anio', 'estado'];
    var columnasSize = ["5", "300", "300", "300", "300", "5", "5"];
    lstLibros = cargaTabla("lstLibros", response, columnas, columnasSize);
    return true;

}

function cargaArchivo() {
    var response = {}; //ejecutarAjax('/API/libroslist/', 'GET', libro);
    response = archivosTemp; //ejecutarAjax('/API/libroslist/', 'GET', libro);
    //console.log(response);
    var columnas = ["cod_archivo", "nom_archivo", 'tip_archivo'];
    var columnasSize = ["5", "300", "5"];
    lstArchivos = cargaTabla("lstArchivos", response, columnas, columnasSize);
    return true;

}

function getLibro(libro) {

    cargaAreas(libro.cod_facultad.cod_facultad);
    $('#txtCodCategoria').val(libro.cod_categoria.cod_categoria);
    $('#txtCodFacultad').val(libro.cod_facultad.cod_facultad);
    $('#txtCodArea').val(libro.cod_area.cod_area);
    $('#txtAutor').val(libro.autor);
    $('#txtTitulo').val(libro.titulo);
    $('#txtAnio').val(libro.anio);
    $('#txtEstado').val(libro.estado);
    $('#txtDescripcion').val(libro.decripcion);
    libro.fec_actu = moment().format('YYYY-MM-DD');
    archivosTemp = ejecutarAjax('/API/libroarchivos/listaporlibro/?clibro=' + libro.cod_libro, 'GET', null);
    $("[id$='img2']").attr('src', libro.bin_img_libro != null ? libro.bin_img_libro : "../../static/img/Sinimagen.gif");

    cargaArchivo(libro);
}
function getArchivo(archivo) {
    /*
        $('#txtCodFacultad').val(archivo.cod_facultad.cod_facultad);
        $('#txtCodArea').val(archivo.cod_area.cod_area);
        $('#txtAutor').val(archivo.autor);
        $('#txtTitulo').val(archivo.titulo);
        $('#txtAnio').val(archivo.anio);
        $('#txtEstado').val(archivo.estado);
        archivo.fec_actu = moment().format('YYYY-MM-DD');
        */
}

function crearLibros() {
    startLoading();
    setTimeout(function () {
        var libro = new Object();
        libro.cod_libro = 0;
        libro.cod_categoria = $('#txtCodCategoria').val();
        libro.cod_facultad = $('#txtCodFacultad').val();
        libro.cod_area = $('#txtCodArea').val();
        libro.autor = $('#txtAutor').val();
        libro.titulo = $('#txtTitulo').val();
        libro.anio = $('#txtAnio').val();
        libro.estado = $('#txtEstado').val();
        libro.decripcion = $('#txtDescripcion').val();
        libro.cod_usr = $(cod_usr).val();
        libro.mca_inh = 'N';
        libro.fec_actu = moment().format('YYYY-MM-DD');

        libro.bin_img_libro = tempBin_libro;
        var response = ejecutarAjax('/API/libros/', 'POST', libro);
        if (archivosTemp != null && archivosTemp.length > 0) {
            archivosTemp.forEach((archivo) => {
                //console.log('Archivos');
                archivo.cod_libro = response.cod_libro;
                var responseArchivo = ejecutarAjax('/API/libroarchivos/', 'POST', archivo);
                archivosTemp = [];
                //console.log(responseArchivo);

            });
        }
        //console.log(response);
        if (response != null) {
            MuestraMensage('success', "Se guardo sactifactoriamente!", " recargaLibros();");
        }
    }, 50);
}
function actualizaLibros(item) {
    startLoading();
    setTimeout(function () {
        if (mcaAprueba == 'N') {
            if (usrTemp != item.cod_usr) {
                MuestraMensage('error', "Usted no tiene permiso para actualizar este registro.", "");
                endLoading();
                return true;
            }
        }
        item.cod_facultad = $('#txtCodFacultad').val();
        item.cod_area = $('#txtCodArea').val();
        item.autor = $('#txtAutor').val();
        item.titulo = $('#txtTitulo').val();
        item.anio = $('#txtAnio').val();
        item.estado = $('#txtEstado').val();
        item.decripcion = $('#txtDescripcion').val();
        item.cod_categoria = $('#txtCodCategoria').val();
        item.cod_usr = $(cod_usr).val(); //$("#cod_usr").val();
        item.mca_inh = 'N';
        item.fec_actu = moment().format('YYYY-MM-DD');
        item.bin_img_libro = tempBin_libro;
        var response = ejecutarAjax('/API/libros/' + item.cod_libro + '/', 'PUT', item);

        if (response != null) {
            if (archivosTemp != null && archivosTemp.length > 0) {
                archivosTemp.forEach((archivo) => {
                    archivo.cod_libro = item.cod_libro;
                    if (archivo.bin_archivo != null)
                        var responseArchivo = ejecutarAjax('/API/libroarchivos/', 'POST', archivo);
                });
            }
            archivosTemp = [];
            item = {};
            MuestraMensage('success', "Se actualizo sactifactoriamente!", "recargaLibros();");
        }
    }, 50);
}

function borraLibros(item) {
    setTimeout(function () {
        if (mcaAprueba == 'N') {
            if (usrTemp != item.cod_usr) {
                MuestraMensage('error', "Usted no tiene permiso para eliminar este registro!", "");
                endLoading();
                return true;
            }
        }
        var response = ejecutarAjax('/API/libros/' + item.cod_libro + '/', 'DELETE', item);
        //console.log(response);
        if (response == null) {
            item = {};
            MuestraMensage('success', "Se ha eliminado sactifactoriamente!");
            recargaLibros();
        }
    }, 50);

}
CargaEstados = () => {

    //Consigo los roles del usuario
    let rolUsr = ejecutarAjax('/API/usuario-roles-list/rolporusuario/?u=' + $(cod_usr).val(), 'GET', null);//

    var $select = $('#txtEstado');
    $select.append('');
    if (rolUsr != null) {

        $.each(rolUsr, function (id, rol) {
            mcaAprueba = rol.cod_rol.mca_aprueba;
            usrTemp = rol.cod_usuario.cod_usuario;
            $select.empty();
            if (mcaAprueba == 'S') {
                $select.append('<option value="">..Seleccione..</option>'
                    + '<option value="P" selected>Pendiente</option>'
                    + '<option value="A">Aprobado</option>'
                    + '<option value="E">Excluido</option>');
                return;
            } else {
                $select.append('<option value="">..Seleccione..</option>'
                    + '<option value="P" selected>Pendiente</option>');

            }
        });

    }
    /*
     */
}
function crearArchivo(libro) {
    startLoading();
    setTimeout(function () {
        var archvo = new Object();
        archvo.cod_libro = libro.cod_libro;
        archvo.cod_archivo = 0;
        archvo.nom_archivo = $("#txtNomArchivo").val();
        archvo.extension = $("#txtExtension").val();
        archvo.tip_archivo = $("#txtTipoArchivo").val();
        archvo.cod_usr = $(cod_usr).val();
        archvo.mca_inh = 'N';
        archvo.fec_actu = moment().format('YYYY-MM-DD');
        var response = ejecutarAjax('/API/libroarchivos/', 'POST', archvo);
        //console.log(response);
        if (response != null) {
            MuestraMensage('success', "Se guardo sactifactoriamente!", " recargaLibros();");
        }
    }, 50);
}

function borraArchivo(item) {
    setTimeout(function () {
        var response = ejecutarAjax('/API/libroarchivos/' + item.cod_archivo + '/', 'DELETE', item);
        if (response == null) {
            $.each(archivosTemp, (index, temp) => {
                if (item.cod_archivo == temp.cod_archivo) {
                    archivosTemp.splice(index, 1);
                    return true;
                }
            });
        }
        cargaArchivo();
    }, 50);

}
function cargaCategoria() {
    var response = ejecutarAjax('/API/categorias/', 'GET', null);
    var $select = $('#txtCodCategoria');
    $select.append('<option value="">..Seleccione..</option>');
    $.each(response, function (id, name) {
        $select.append('<option value=' + name.cod_categoria + '>' + name.nom_categoria + '</option>');
    });
}

function cargaFacultades() {
    var response = ejecutarAjax('/API/listfacultad/', 'GET', null);
    var $select = $('#txtCodFacultad');
    $select.append('<option value="">..Seleccione..</option>');
    $.each(response, function (id, name) {
        $select.append('<option value=' + name.cod_facultad + '>' + name.nombre + '</option>');
    });
}

function cargaAreas(cod_facultad) {
    var response = ejecutarAjax('/API/areas/', 'GET', null);
    var responseFilter = [];
    response.filter(function (item) {
        if (item.cod_facultad == cod_facultad) {
            responseFilter.push(item);
            return;
        }
    });
    var $select = $('#txtCodArea');
    $select.empty();

    $select.append('<option value="">..Seleccione..</option>');
    $.each(responseFilter, function (id, name) {
        $select.append('<option value=' + name.cod_area + '>' + name.nom_area + '</option>');
    });
}
const convertBase64 = (file) => {
    return new Promise((resolve, reject) => {
        const fileReader = new FileReader();
        fileReader.readAsDataURL(file);

        fileReader.onload = () => {
            resolve(fileReader.result);
        };

        fileReader.onerror = (error) => {
            reject(error);
        };
    });
};
const subirArchivo = async (event) => {
    const file = event.target.files[0];
    const base64 = await convertBase64(file);
    const tipArchivo = file.name.split(".")[1];
    //Agrego en memoria el archivo cargado.
    var archvo = new Object();
    $("#txtNomArchivo").val(file.name);

    $("#txtExtension").val("." + tipArchivo);
    $("#txtTipoArchivo").val(((tipArchivo.toLowerCase() == 'doc' || tipArchivo.toLowerCase() == 'docx' ? 'doc' : tipArchivo)).toUpperCase());
    tempBin_archivo = base64;
};

const adjuntarArhicvoTemp = (libro) => {
    var existe = false;
    $.each(archivosTemp, (index, temp) => {
        if (temp.extension == $("#txtExtension").val()) {
            MuestraMensage('error', "Ya existe un archivo " + temp.extension, "");
            existe = true;
            return true;
        }
    });
    if (!existe) {
        var archvo = new Object();
        archvo.cod_libro = libro != null ? libro.cod_libro : 0;
        archvo.cod_archivo = 0;
        archvo.nom_archivo = $("#txtNomArchivo").val();
        archvo.extension = $("#txtExtension").val();
        archvo.tip_archivo = $("#txtTipoArchivo").val();
        archvo.cod_usr = $(cod_usr).val();
        archvo.mca_inh = 'N';
        archvo.fec_actu = moment().format('YYYY-MM-DD');
        archvo.bin_archivo = tempBin_archivo;
        archivosTemp.push(archvo);
        cargaArchivo();
        tempBin_archivo = null;
    }
    $('#modalArchivos').modal('hide');
    $('#modalCRUD').modal('show');
}


async function cargaImg(event) {
    const file = event.target.files[0];
    const imgBase64 = await convertBase64(file);
    tempBin_libro = imgBase64;
    $("[id$='img2']").attr('src', URL.createObjectURL(file));
}
