$(document).ready(main);
var lstUsuarioRol = null;
var isEditing = false;
var item = {};
var accion = null;
var btnname = 'Guardar';
function main() {
    
    try {
        recargaUsuarioRol();
        cargaroles();
        cargausuarios();
        //--
        $("#btnCNuevo").on('click', function () {
            limpiarCampos('dvUsuarioRol');
            btnname = "Guardar";
            $("#btnCreaUsuarioRol").text(btnname);
            isEditing = false;
            $('#modalCRUD').modal('show');
        });
        //--
        $('#btnCreaUsuarioRol').on('click', function () {
            if (validarDiv('formUsuarioRol')) {
                if (isEditing) {
                    btnname = "Actualizar";
                    $("#btnCreaUsuarioRol").text(btnname);
                    actualizaUsuarioRol(item);
                } else {
                    startLoading();
                    //console.log("entre");
                    btnname = "Guardar";
                    $("#btnCreaUsuarioRol").text(btnname);
                    crearUsuarioRol();
                }
                recargaUsuarioRol();
                $('#modalCRUD').modal('hide');
            }
        });
        //--
        $('#lstUsuarioRol tbody').on('click', 'tr td img', function () {
            accion = $(this).prop('id');
            //console.log(accion);
            item = lstUsuarioRol.row($(this).parent().parent()).data();
            $('#txtCodrol').val(item.cod_rol);
            $('#txtNomUsuario').val(item.nom_UsuarioRol);
            if (item.cod_UsuarioRol != null && item.cod_UsuarioRol > 0) {
                isEditing = true;
            }
            if (accion == 'delete') {
                $.alert.open('confirm', 'Confirmar', "Esta seguro que quiere eliminar este registro?", (button) => {
                    if (button == 'yes') {
                        borraUsuarioRol(item);
                        return true;
                    } else {
                        return;
                    }

                });
            } else {
                btnname = "Actualizar";
                $("#btnCreaUsuarioRol").text(btnname);
                $('#modalCRUD').modal('show');
            }
        });


    } catch (e) {
        //debugger
    }
}

function recargaUsuarioRol() {
    $("#lstUsuarioRol").DataTable().destroy();
    cargaUsuarioRol();

}

function cargaUsuarioRol() {
    var UsuarioRol = new Object();
    var response = ejecutarAjax('/API/usuario-roles-list/', 'GET', UsuarioRol);
    //console.log(response);
    var columnas = ["cod_usuario_rol", "cod_usuario.nombre", 'cod_rol.nombre'];
    var columnasSize = ["5", "250", "300", "5"];
    lstUsuarioRol = cargaTabla("lstUsuarioRol", response, columnas, columnasSize);
    return true;

}

function crearUsuarioRol() {
    var UsuarioRol = new Object();
    UsuarioRol.cod_usr = $(cod_usr).val();
    UsuarioRol.cod_usuario_rol = 0;
    UsuarioRol.cod_usuario = $('#txtCodusuario').val();
    UsuarioRol.cod_rol = $('#txtCodRol').val();
    UsuarioRol.mca_inh = 'N';
    UsuarioRol.fec_actu = moment().format('YYYY-MM-DD');
    var response = ejecutarAjax('/API/usuario-roles/', 'POST', UsuarioRol);
    //console.log(response);
    if (response != null) {
        MuestraMensage('success', "Se guardo sactifactoriamente!","endLoading();");
    }
}
function actualizaUsuarioRol(item) {

    item.fec_actu = moment().format('YYYY-MM-DD');
    item.cod_usuario = $('#txtCodusuario').val();
    item.cod_rol = $('#txtCodRol').val();
    var response = ejecutarAjax('/API/usuario-roles/' + item.cod_usuario_rol + '/', 'PUT', item);
    if (response != null) {
        item = {};
        MuestraMensage('success', "Se actualizo sactifactoriamente!");
    }
}

function borraUsuarioRol(item) {
    var response = ejecutarAjax('/API/usuario-roles/' + item.cod_usuario_rol + '/', 'DELETE', item);
    //console.log(response);
    if (response == null) {
        item = {};
        MuestraMensage('success', "Se eliminado sactifactoriamente!");
        recargaUsuarioRol();
    }

}

function cargaroles() {
    var response = ejecutarAjax('/API/roles/', 'GET', null);
    var $select = $('#txtCodRol');
    $select.append('<option value="">..Seleccione..</option>');
    $.each(response, function (id, name) {
        $select.append('<option value=' + name.cod_rol + '>' + name.nombre + '</option>');
    });
}

function cargausuarios() {
  var response = ejecutarAjax('/API/usuario/', 'GET', null);
  var $select = $('#txtCodusuario');
  $select.append('<option value="">..Seleccione..</option>');
  $.each(response, function (id, name) {
      $select.append('<option value=' + name.cod_usuario + '>' + name.nombre + ' ' + name.apellido + '</option>');
  });
}
