"""RepositorioDeDocumentos URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from os import name
from turtle import home
from django.urls import path
from dashboard.controller.home import Home

urlpatterns = [
    path('', Home.index, name='HomeIndex'),
    path('libros/', Home.libros, name='libros'),
    path('facultad/', Home.facultad, name='facultad'),
    path('areas/', Home.areas, name = 'areas'),
    path('tipoarea/', Home.tipoAreas, name = 'tipoarea'),
    path('categorias/', Home.categorias, name='categorias'),
    path('usuarios/', Home.usuarios, name='usuarios'),
    path('roles/',  Home.roles, name='roles'),
    path('usuarios-roles/', Home.usuarios_roles, name='usuarios_roles'),
    path('privilegios-roles/', Home.privilegiosRoles, name='privilegios_roles'),
]
