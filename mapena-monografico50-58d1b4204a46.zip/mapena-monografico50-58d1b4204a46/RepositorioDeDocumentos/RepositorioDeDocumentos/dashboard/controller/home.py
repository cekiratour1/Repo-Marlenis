from django.shortcuts import render, redirect
from API.functions.dashboard.session import Session
from API.functions.dashboard.dashboardConfig import render_privilege

class Home():
    #NOTA IMPORTANTE: usar la función render_privilege si quieren que renderice tomando en cuenta los privilegios
    def libros(request):
        return render_privilege(request, 'dashboard/administracionlibros.html')

    def index(request):
        return render(request, 'dashboard/layout.html', Session.get(request))

    def facultad(request):
       return render_privilege(request, 'dashboard/facultad.html')

    def areas(request):
        return render_privilege(request, 'dashboard/areas.html')

    def categorias(request):
        return render_privilege(request, 'dashboard/categorias.html')

    def usuarios(request):
        if Session.auth(request) == False:
            return redirect('LoginIndex')

        data = Session.get(request)

        return render_privilege(request, 'dashboard/usuarios.html', data)

    def roles(request):
        return render_privilege(request, 'dashboard/roles.html')
    
    def usuarios_roles(request):
        return render_privilege(request, 'dashboard/usuarios-roles.html')

    def tipoAreas(request):
        return render_privilege(request, 'dashboard/tipoareas.html')

    def privilegiosRoles(request):
        return render_privilege(request, 'dashboard/privilegios/roles.html')