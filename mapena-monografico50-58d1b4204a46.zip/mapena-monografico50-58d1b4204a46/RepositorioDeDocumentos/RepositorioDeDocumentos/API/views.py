from django.shortcuts import render,redirect
from API.functions.email.send import EnviarMail
"""
    Validacion login
"""
def Send_mail(request):

    name  = request.POST['name']
    email = request.POST['email']
    message = request.POST['message']
    phone = request.POST['phone']
    EnviarMail(name, email, phone, message)
