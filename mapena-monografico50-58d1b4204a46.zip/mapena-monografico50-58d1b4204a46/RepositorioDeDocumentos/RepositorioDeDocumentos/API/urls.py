from django.urls import path
from .viewsets.UsuarioViewSet import UsuarioViewSet, UsuarioRolViewSet, RolViewSet, UsuarioRolListaViewSet
from .viewsets.LibroViewset import  LibroListaViewSet,LibroViewset, LibroArchivoViewset
from .viewsets.dashboardViewset import  ViewSetlistarFacultad, ViewSetCrearFacultad
from .viewsets.CategoriaViewset import ViewSetCategoria
from .viewsets.AreaViewset import AreaViewset, AreaListaViewSet, TipoAreaViewSet
from .viewsets.PrivilegioViewset import MenuViewset, MenuRolViewset, CambiarMenuRolViewset
from .viewsets.SitioWebViewset import ViewSetSitioWeb
from rest_framework import routers
from API import views

#Instanciamos el objeto router donde se registrara todas las rutas de la API
router = routers.DefaultRouter()
#Registramos la ruta de nuestro objeto
router.register('usuario', UsuarioViewSet, 'usuarios')
router.register('usuario-roles', UsuarioRolViewSet, 'usr_roles')
router.register('usuario-roles-list', UsuarioRolListaViewSet,'usr_roles_list')
router.register('roles', RolViewSet, 'roles')
#------------------------------------------------------
""" Libros (MP) """
router.register('libros',LibroViewset,'libro')
router.register('libroslist',LibroListaViewSet,'libroslist')
router.register('libroarchivos',LibroArchivoViewset,'libroarchivos')

""" Facultad """
router.register('listfacultad',ViewSetlistarFacultad,'list_fac')
router.register('crearfacultad',ViewSetCrearFacultad,'crea_fac')
""" Area (MP) """
router.register('areas',AreaViewset,'area')
router.register('areaslist',AreaListaViewSet,'areaslist')
router.register('tipoareas',TipoAreaViewSet,'tipoareas')

""" Categoria (MP) """
router.register('categorias',ViewSetCategoria,'categoria')

""" Privilegios """
router.register('menu', MenuViewset, 'menu')
router.register('menu-rol', MenuRolViewset, 'menu-rol')
router.register('menu-rol-change', CambiarMenuRolViewset, 'menu-rol-change')

#Registramos todas las rutas que almacena el objeto router 
urlpatterns = router.urls
