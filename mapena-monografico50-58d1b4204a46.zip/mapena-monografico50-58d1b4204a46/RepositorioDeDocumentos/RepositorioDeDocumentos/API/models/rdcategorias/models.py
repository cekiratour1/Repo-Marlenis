from django.db import models

# Create your models here.
from datetime import datetime
from enum import unique
from unittest.util import _MAX_LENGTH

class categoria(models.Model):
    cod_categoria = models.AutoField(primary_key=True)
    nom_categoria = models.TextField(max_length=100)
    cod_usr = models.IntegerField()
    fec_actu = models.DateField()
    mca_inh = models.CharField(default='N',max_length=1)
    fec_crea = models.DateField(default=datetime.now().strftime('%Y-%m-%d'))
