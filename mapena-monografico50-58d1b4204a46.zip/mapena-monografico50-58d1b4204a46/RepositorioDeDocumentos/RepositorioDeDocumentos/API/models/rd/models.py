from datetime import datetime
from enum import unique
from unittest.util import _MAX_LENGTH
from xml.dom.minidom import Entity
from django.db import models
"""
    Tabla Facultad (CP) ch
"""
class facultad(models.Model):
    cod_facultad = models.AutoField(primary_key=True)
    cod_usr = models.IntegerField()
    nombre = models.TextField(max_length=100)
    fec_actu = models.DateField(default=datetime.now().strftime('%Y-%m-%d'))
    #marca de inactividad
    mca_inh = models.CharField(max_length=1)
    fec_crea = models.DateField(default=datetime.now().strftime('%Y-%m-%d'))

"""
    Tabla Tipo Area
"""
class tipoarea(models.Model):
    cod_tipoarea = models.AutoField(primary_key=True,default='F')
    nom_tipoarea = models.CharField(max_length=100, default='N')
    cod_usr = models.IntegerField()
    fec_crea = models.DateField(default=datetime.now().strftime('%Y-%m-%d'))
    fec_actu = models.DateField()
    mca_inh = models.CharField(max_length=1, default='N')

"""
    Tabla Area (MP)
"""
class area(models.Model):
    cod_area = models.AutoField(primary_key=True)
    cod_facultad = models.ForeignKey(facultad, related_name='facultad', on_delete=models.CASCADE)
    nom_area = models.TextField(max_length=100)
    cod_tipoarea = models.ForeignKey(tipoarea, related_name='tipoarea', on_delete=models.CASCADE)
    cod_usr = models.IntegerField()
    fec_crea = models.DateField(default=datetime.now().strftime('%Y-%m-%d'))
    fec_actu = models.DateField()
    mca_inh = models.CharField(max_length=1, default='N')

