from django.db import models
from API.models.rdusuario.models import Usuario, Rol
from datetime import datetime

class Menu(models.Model):
    cod_menu = models.AutoField(primary_key=True)
    cod_menu_padre = models.ForeignKey('self', null=True, blank=True, on_delete=models.CASCADE)
    nombre_menu = models.CharField(max_length=30, default=None)
    url_menu = models.CharField(max_length=50, default=None)
    url_icono = models.CharField(max_length=150, default=None)
    cod_usr = models.ForeignKey(Usuario, on_delete=models.CASCADE)

class MenuRol(models.Model):
    cod_menu_rol = models.AutoField(primary_key=True)
    cod_menu = models.ForeignKey(Menu, on_delete=models.CASCADE)
    cod_rol = models.ForeignKey(Rol, on_delete=models.CASCADE)
    cod_usr = models.ForeignKey(Usuario, on_delete=models.CASCADE)
    fec_actu = models.DateField(default=datetime.now().strftime('%Y-%m-%d'))