from django.db import models
from datetime import datetime

""" 
    Tabla Usuarios
"""
class Usuario(models.Model):
    cod_usuario = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=30)
    apellido = models.CharField(max_length=30)
    usuario = models.CharField(max_length=30)
    contrasena = models.CharField(max_length=150)
    correo = models.CharField(max_length=50)
    fec_actu = models.DateField(blank=True, null=True)
    mca_inh = models.CharField(max_length=1, default='N')
    fec_crea = models.DateField(default=datetime.now().strftime('%Y-%m-%d'),blank=True)

"""
    Tabla Roles
"""
class Rol(models.Model):
    cod_rol = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=30)
    mca_aprueba = models.CharField(max_length=1, default='N')
    fec_actu = models.DateField(blank=True, null=True)
    mca_inh = models.CharField(max_length=1, default='N')
    cod_usr = models.IntegerField()
    fec_crea = models.DateField(default=datetime.now().strftime('%Y-%m-%d'))

"""
    Tabla Rol por usuario
"""
class UsuarioRol(models.Model):
    cod_usuario_rol = models.AutoField(primary_key=True)
    cod_usuario = models.ForeignKey(Usuario, related_name='Usuario', on_delete=models.CASCADE)
    cod_rol = models.ForeignKey(Rol, related_name='Rol', on_delete=models.CASCADE)
    fec_actu = models.DateField(blank=True, null=True)
    mca_inh = models.CharField(max_length=1, default='N')
    cod_usr = models.IntegerField(default=0)
    fec_crea = models.DateField(default=datetime.now().strftime('%Y-%m-%d'))

