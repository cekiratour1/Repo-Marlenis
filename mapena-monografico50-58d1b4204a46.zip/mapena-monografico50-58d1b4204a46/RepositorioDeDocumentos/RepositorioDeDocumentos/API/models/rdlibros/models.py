from django.db import models

# Create your models here.
from datetime import datetime
from enum import auto, unique
from unittest.util import _MAX_LENGTH
from API.models.rd.models import facultad, area
from API.models.rdcategorias.models import categoria 


class libro(models.Model):
    cod_libro = models.AutoField(primary_key=True)
    cod_facultad = models.ForeignKey(facultad, related_name='facultads', on_delete=models.CASCADE)
    cod_area = models.ForeignKey(area, related_name='areas', on_delete=models.CASCADE)
    cod_categoria = models.ForeignKey(categoria, related_name='categoria', on_delete=models.CASCADE)
    autor = models.CharField(max_length=100)
    titulo = models.CharField(max_length=100)
    decripcion = models.CharField(max_length=2000)
    anio = models.IntegerField()
    bin_img_libro = models.TextField(null=True)
    estado = models.CharField(default='P',max_length=1)#los estados puden ser 3 'P'=Pendiente, 'A'=Aprobado, 'E'=Excluido
    cod_usr = models.IntegerField()
    fec_actu = models.DateField()
    mca_inh = models.CharField(default='N',max_length=1)
    fec_crea = models.DateField(default=datetime.now().strftime('%Y-%m-%d'))

class archivo(models.Model):
    cod_archivo= models.AutoField(primary_key=True,null=False)
    cod_libro = models.ForeignKey(libro, related_name='archivo', on_delete=models.CASCADE)
    nom_archivo= models.CharField(max_length=100,null=False)
    extension = models.CharField(max_length=8,null=False)
    tip_archivo = models.CharField(max_length=5,null=False)#los tipos de archivos pueden ser doc,pdf,html
    #archivo=models.BinaryField()
    bin_archivo = models.TextField()
    cod_usr = models.IntegerField()
    fec_actu = models.DateField()
    mca_inh = models.CharField(default='N',max_length=1)
    fec_crea = models.DateField(default=datetime.now().strftime('%Y-%m-%d'))
