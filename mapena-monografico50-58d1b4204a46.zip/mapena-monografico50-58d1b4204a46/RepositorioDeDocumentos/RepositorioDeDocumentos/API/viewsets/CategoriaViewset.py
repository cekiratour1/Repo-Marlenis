
from rest_framework import viewsets, permissions
from API.serializers.CategoriaSerializer import CategoriaSerializer
from API.models.rdcategorias.models import categoria
"""
    Creacion de los viewsets 
"""
class ViewSetCategoria(viewsets.ModelViewSet):
    #Escogemos la consulta para buscar los archivos
    queryset = categoria.objects.all()
    #Elegimos quien podra ver los datos si esta autenticado o simplemente lo permitimos a todos
    permission_classes = [permissions.AllowAny]
    #La clase serializadora encargada de transformar los datos
    serializer_class = CategoriaSerializer
    http_method_names =['get', 'post', 'put', 'delete']