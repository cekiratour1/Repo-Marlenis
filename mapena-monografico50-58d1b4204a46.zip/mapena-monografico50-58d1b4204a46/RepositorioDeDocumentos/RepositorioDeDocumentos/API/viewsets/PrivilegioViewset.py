
from rest_framework import viewsets, permissions
from API.serializers.PrivilegioSerializer import MenuSerializer, MenuRolSerializer, CambiarMenuRolSerializer
from API.models.rdmenu.models import Menu, MenuRol

"""
    Creacion de los viewsets 
"""
class MenuViewset(viewsets.ModelViewSet):
    #Escogemos la consulta para buscar los archivos
    queryset = Menu.objects.all()
    #Elegimos quien podra ver los datos si esta autenticado o simplemente lo permitimos a todos
    permission_classes = [permissions.AllowAny]
    #La clase serializadora encargada de transformar los datos
    serializer_class = MenuSerializer
    http_method_names = ['get']
    
class MenuRolViewset(viewsets.ModelViewSet):
    #Escogemos la consulta para buscar los archivos
    queryset = MenuRol.objects.all()
    #Elegimos quien podra ver los datos si esta autenticado o simplemente lo permitimos a todos
    permission_classes = [permissions.AllowAny]
    #La clase serializadora encargada de transformar los datos
    serializer_class = MenuRolSerializer
    http_method_names = ['get']

class CambiarMenuRolViewset(viewsets.ModelViewSet):
    # Escogemos la consulta para buscar los archivos
    queryset = MenuRol.objects.all()
    # Elegimos quien podra ver los datos si esta autenticado o simplemente lo permitimos a todos
    permission_classes = [permissions.AllowAny]
    # La clase serializadora encargada de transformar los datos
    serializer_class = CambiarMenuRolSerializer
    http_method_names = ['post', 'put', 'delete']