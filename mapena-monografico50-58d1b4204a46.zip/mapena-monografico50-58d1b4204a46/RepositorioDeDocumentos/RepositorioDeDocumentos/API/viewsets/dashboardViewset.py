
from rest_framework import viewsets, permissions
from rest_framework.decorators import action 
from rest_framework.response import Response
from API.serializers.DashboardSerializer import ListaSerializer,CrearSerializer
from API.models.rd.models import facultad
"""
    Creacion de los viewsets 
"""
class ViewSetlistarFacultad(viewsets.ModelViewSet):
    #Escogemos la consulta para buscar los archivos
    queryset = facultad.objects.all()
    #Elegimos quien podra ver los datos si esta autenticado o simplemente lo permitimos a todos
    permission_classes = [permissions.AllowAny]
    #La clase serializadora encargada de transformar los datos
    serializer_class = ListaSerializer
    @action(detail=True)
    def prueba(self,request):
        print("Se ejecuta esto")
        return Response({"status":"Prueba funcion API"})
"""
    Registro Users
"""
class ViewSetCrearFacultad(viewsets.ModelViewSet):
    queryset = facultad.objects.all()
    permission_classes = [permissions.AllowAny]
    serializer_class = CrearSerializer
