
from rest_framework import viewsets, permissions
#from API.serializers.SitioWebSerializer import SitioWebSerializer
from rest_framework.decorators import action
from rest_framework.response import Response
"""
    Creacion de los viewsets 
"""
class ViewSetSitioWeb(viewsets.ModelViewSet):
    pass
    #Escogemos la consulta para buscar los archivos
    #queryset = Correo.objects.all()
    #Elegimos quien podra ver los datos si esta autenticado o simplemente lo permitimos a todos
    #permission_classes = [permissions.AllowAny]
    #La clase serializadora encargada de transformar los datos
    #serializer_class = SitioWebSerializer
    
    
    #@action(detail=False, methods=['post'])
    #def enviar_correo(self, request):
        #print(resquest.POST['email'])
        #print("Valores de request: " + request.data)
        #serializer = SitioWebSerializer(data=request.data)
        #return Response({ 'datosSerializados': serializer })
    
