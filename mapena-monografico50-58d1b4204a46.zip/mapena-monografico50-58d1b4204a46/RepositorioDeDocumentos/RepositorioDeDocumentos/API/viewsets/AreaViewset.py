
from rest_framework import viewsets, permissions
from API.serializers.AreaSerializer import ListaAreaSerializer, AreaCrearSerializer, TipoAreaSerializer
from API.models.rd.models import area,tipoarea

"""
    Creacion de los viewsets 
"""
class AreaViewset(viewsets.ModelViewSet):
    #Escogemos la consulta para buscar los archivos
    queryset = area.objects.all()
    #Elegimos quien podra ver los datos si esta autenticado o simplemente lo permitimos a todos
    permission_classes = [permissions.AllowAny]
    #La clase serializadora encargada de transformar los datos
    serializer_class = AreaCrearSerializer
    http_method_names =['get','post','put', 'delete']
    
class AreaListaViewSet(viewsets.ModelViewSet):
    #Escogemos la consulta para buscar los archivos
    queryset = area.objects.all()
    #Elegimos quien podra ver los datos si esta autenticado o simplemente lo permitimos a todos
    permission_classes = [permissions.AllowAny]
    #La clase serializadora encargada de transformar los datos
    serializer_class = ListaAreaSerializer
    http_method_names =['get']

class TipoAreaViewSet(viewsets.ModelViewSet):
    #Escogemos la consulta para buscar los archivos
    queryset = tipoarea.objects.all()
    #Elegimos quien podra ver los datos si esta autenticado o simplemente lo permitimos a todos
    permission_classes = [permissions.AllowAny]
    #La clase serializadora encargada de transformar los datos
    serializer_class = TipoAreaSerializer
    http_method_names =['get', 'post', 'put', 'delete']