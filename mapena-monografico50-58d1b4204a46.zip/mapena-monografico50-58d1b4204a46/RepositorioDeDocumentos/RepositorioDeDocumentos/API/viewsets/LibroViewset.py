from asyncio.windows_events import NULL
from datetime import datetime 
from pickle import NONE
from rest_framework import viewsets, permissions
from rest_framework.response import Response
from rest_framework.decorators import action
from API.serializers.LibrosSerializer import LibroListaSerializer, LibroCrearSerializer,ArchivoCrearSerializer,ListaArchivoNoBinSerializer, ArchivoBinSerializer
#Temporal -- Modelo Facultad
from API.models.rd.models import facultad
from API.serializers.DashboardSerializer import ListaSerializer 
#----------------------------------------------------------------
from API.models.rdlibros.models import libro, archivo
"""
    Creacion de los viewsets 
"""
class LibroViewset(viewsets.ModelViewSet):
    #Escogemos la consulta para buscar los archivos
    queryset = libro.objects.all()
    #Elegimos quien podra ver los datos si esta autenticado o simplemente lo permitimos a todos
    permission_classes = [permissions.AllowAny]
    #La clase serializadora encargada de transformar los datos
    serializer_class = LibroCrearSerializer
    http_method_names =['get','post','put', 'delete']   
    
class LibroListaViewSet(viewsets.ModelViewSet):
    #Escogemos la consulta para buscar los archivos
    queryset = libro.objects.all()
    #Elegimos quien podra ver los datos si esta autenticado o simplemente lo permitimos a todos
    permission_classes = [permissions.AllowAny]
    #La clase serializadora encargada de transformar los datos
    serializer_class = LibroListaSerializer
    http_method_names =['get']
    #-------------------------------------------------
    @action(detail=False,methods=['get'])
    def librosporestado(self, request):
        try:
            value = request.query_params['st']
        except:
            value ='all'
        #-------------------------------
        
        queryset = libro.objects.raw("SELECT top (10) * FROM rdlibros_libro where estado = IIf('"+value+"'= 'all', estado,'"+value+"') order by cod_libro desc ")
        serializer = LibroListaSerializer(queryset, many=True)
        return Response(serializer.data)
    #--------------------------------------------------
    @action(detail=False,methods=['get'])
    def librosporfiltro(self, request):
        cadena = ''

        ##Facultad
        try:
            fc = ''
            fc = request.query_params['fc']

            if fc != '':
                cadena += "and cod_facultad_id ='"+fc+"'"
        
        except:
            if fc == '':
                fc = None
        
        #Area
        try:
            ar = ''
            ar = request.query_params['ar']

            if ar != 'null' :
                cadena += " and cod_area_id ='"+ar+"'"

        except:
            if ar == '' or ar == 'null':
                ar = None
            
        #Criterio de busqueda por titulo
        try:
            cr = ''
            cr = request.query_params['cr']

            if cr != '':
                cadena += " and titulo like '%%"+cr+"%%'"
        
        except:
            if cr == '':
                cr = None

        #categoria
        try:
            cat = ''
            cat = request.query_params['cat']

            if cat != '':
                cadena += " and cod_categoria_id ="+cat+""
        
        except:
            if cat == '':
                cat = None



        #-------------------------------
        cadena = (f"SELECT * FROM rdlibros_libro where estado = 'A' {cadena} order by cod_libro desc ")
        queryset = libro.objects.raw(cadena)
                                    
                                    
                                    
                                    
        serializer = LibroListaSerializer(queryset, many=True)
        return Response(serializer.data)
    #--------------------------------------------------

class LibroArchivoViewset(viewsets.ModelViewSet):
    #Escogemos la consulta para buscar los archivos
    queryset = archivo.objects.all()
    #Elegimos quien podra ver los datos si esta autenticado o simplemente lo permitimos a todos
    permission_classes = [permissions.AllowAny]
    #La clase serializadora encargada de transformar los datos
    serializer_class = ArchivoCrearSerializer
    http_method_names =['get','post','put', 'delete']
    #-------------------------------------------------
    @action(detail=False,methods=['get'])
    def listaporlibro(self, request):
        try:
            codLibro = request.query_params['clibro']
        except:
            return Response(status=404)

        queryset = archivo.objects.raw(f"SELECT cod_archivo, cod_libro_id,nom_archivo,extension, tip_archivo,cod_usr, fec_actu,mca_inh,fec_crea FROM rdlibros_archivo WHERE cod_libro_id = {codLibro}")
        serializer = ListaArchivoNoBinSerializer(queryset, many=True)
        return Response(serializer.data)
    #--------------------------------------------------
    #-------------------------------------------------
    @action(detail=False,methods=['get'])
    def descargaarchivo(self, request):
        try:
            codLibro = request.query_params['clibro']
            tip_archivo = request.query_params['ctipo']
        except:
            return Response(status=404)

        queryset = archivo.objects.raw(f"SELECT cod_archivo, bin_archivo FROM rdlibros_archivo WHERE cod_libro_id = {codLibro} and tip_archivo='{tip_archivo}'")
        serializer = ArchivoBinSerializer(queryset, many=True)
        return Response(serializer.data)
    #--------------------------------------------------
    #ListaArchivoNoBinSerializer
