from rest_framework import viewsets, permissions
from rest_framework.response import Response
from rest_framework.decorators import action
from API.serializers.UsuarioSerializer import UsuarioSerializer, ListaUsuarioRolSerializer, UsuarioRolCrearSerializer, RolSerializer
from API.models.rdusuario.models import Usuario, UsuarioRol, Rol

class UsuarioViewSet(viewsets.ModelViewSet):
    #Escogemos la consulta para buscar los archivos
    queryset = Usuario.objects.filter(mca_inh='N')
    #Elegimos quien podra ver los datos si esta autenticado o simplemente lo permitimos a todos
    permission_classes = [permissions.AllowAny]
    #La clase serializadora encargada de transformar los datos
    serializer_class = UsuarioSerializer

class RolViewSet(viewsets.ModelViewSet):
    #Escogemos la consulta para buscar los archivos
    queryset = Rol.objects.filter(mca_inh='N')
    #Elegimos quien podra ver los datos si esta autenticado o simplemente lo permitimos a todos
    permission_classes = [permissions.AllowAny]
    #La clase serializadora encargada de transformar los datos
    serializer_class = RolSerializer
    
class UsuarioRolViewSet(viewsets.ModelViewSet):
    #Escogemos la consulta para buscar los archivos
    queryset = UsuarioRol.objects.all()
    #Elegimos quien podra ver los datos si esta autenticado o simplemente lo permitimos a todos
    permission_classes = [permissions.AllowAny]
    #La clase serializadora encargada de transformar los datos
    serializer_class = UsuarioRolCrearSerializer
    http_method_names =['post','put', 'delete']
    
class UsuarioRolListaViewSet(viewsets.ModelViewSet):
    #Escogemos la consulta para buscar los archivos
    queryset = UsuarioRol.objects.all()
    #Elegimos quien podra ver los datos si esta autenticado o simplemente lo permitimos a todos
    permission_classes = [permissions.AllowAny]
    #La clase serializadora encargada de transformar los datos
    serializer_class = ListaUsuarioRolSerializer
    http_method_names =['get']
    #-------------------------------------------------
    @action(detail=False,methods=['get'])
    def rolporusuario(self, request):
        try:
            value = request.query_params['u']
        except:
            value =0
    #-------------------------------
        queryset = UsuarioRol.objects.raw(f"SELECT * FROM rdusuario_usuariorol where cod_usuario_id={value} ")
        serializer = ListaUsuarioRolSerializer(queryset, many=True)
        return Response(serializer.data)
    #--------------------------------------------------
