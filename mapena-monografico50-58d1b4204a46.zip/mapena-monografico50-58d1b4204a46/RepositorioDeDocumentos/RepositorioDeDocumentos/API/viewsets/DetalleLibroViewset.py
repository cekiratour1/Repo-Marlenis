from asyncio.windows_events import NULL
from datetime import datetime 
from pickle import NONE
from rest_framework import viewsets, permissions
from rest_framework.response import Response
from rest_framework.decorators import action
from API.serializers.LibrosSerializer import LibroListaSerializer, LibroCrearSerializer,ArchivoCrearSerializer,ListaArchivoNoBinSerializer
#Temporal -- Modelo Facultad
from API.models.rd.models import facultad
from API.serializers.DashboardSerializer import ListaSerializer 
#----------------------------------------------------------------
from API.models.rdlibros.models import libro, archivo

class DetalleLibroViewSet(viewsets.ModelViewSet):
    #Escogemos la consulta para buscar los archivos
    #queryset = libro.objects.all()
    queryset = libro.objects.filter(cod_libro='N')
    #Elegimos quien podra ver los datos si esta autenticado o simplemente lo permitimos a todos
    permission_classes = [permissions.AllowAny]
    #La clase serializadora encargada de transformar los datos
    serializer_class = LibroListaSerializer
    http_method_names =['get']
