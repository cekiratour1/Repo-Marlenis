
from dataclasses import fields
from rest_framework import serializers
from API.models.rd.models import facultad, tipoarea

"""
    Creacion de la clase que queremos serializar
"""
class ListaSerializer(serializers.ModelSerializer):
    class Meta:
        model= facultad
        fields = ('cod_facultad','nombre');

class ListaTipoAreaSerializer(serializers.ModelSerializer):
    class Meta:
        model= tipoarea
        fields = ('cod_tipoarea','nom_tipoarea');

class CrearSerializer(serializers.ModelSerializer):
    class Meta:
        model= facultad
        fields = (
            'cod_facultad',
            'nombre',
            'cod_usr',
            'mca_inh'
            );

class actualizarSerializer(serializers.ModelSerializer):
    class Meta:
        model= facultad
        fields = (
            'cod_facultad',
            'nombre',
            'cod_usr',
            'fec_actu'
            );

class EliminarSerializer(serializers.ModelSerializer):
    class Meta:
        model= facultad
        fields = (
            'cod_facultad',
            'cod_usr',
            'mca_inh',
            'fec_actu'
            );