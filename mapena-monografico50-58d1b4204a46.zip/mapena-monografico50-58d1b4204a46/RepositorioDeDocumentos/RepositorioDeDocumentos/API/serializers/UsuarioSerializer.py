from rest_framework import serializers
from API.models.rdusuario.models import Usuario, UsuarioRol, Rol

"""
    Creacion de la clase que queremos serializar
"""
class UsuarioSerializer(serializers.ModelSerializer):
    class Meta:
        #Aqui especificamos del modelo de la base de datos para luego crear el viewset 
        model = Usuario
        #Aqui especificamos los campos a devolver, podriamos ponerlos de solo lectura
        fields = '__all__'

class RolSerializer(serializers.ModelSerializer):
    class Meta:
        #Aqui especificamos del modelo de la base de datos para luego crear el viewset 
        model = Rol
        #Aqui especificamos los campos a devolver, podriamos ponerlos de solo lectura
        fields = '__all__'
        
class ListaUsuarioRolSerializer(serializers.ModelSerializer):
    cod_usuario = UsuarioSerializer(read_only=True)
    cod_rol = RolSerializer(read_only=True)
    class Meta:
        #Aqui especificamos del modelo de la base de datos para luego crear el viewset 
        model = UsuarioRol
        #Aqui especificamos los campos a devolver, podriamos ponerlos de solo lectura
        fields = '__all__'

class UsuarioRolCrearSerializer (serializers.ModelSerializer):
    class Meta:
        model= UsuarioRol
        fields = (
            'cod_usuario_rol',
            'cod_usuario',
            'cod_rol',
            'fec_actu',
            'cod_usr',
            'mca_inh',
            'fec_crea'
        )
