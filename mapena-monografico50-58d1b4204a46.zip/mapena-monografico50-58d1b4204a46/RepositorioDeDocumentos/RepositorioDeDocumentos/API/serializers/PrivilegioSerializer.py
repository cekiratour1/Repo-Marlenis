from rest_framework import serializers
from API.models.rdmenu.models import Menu,MenuRol
from API.serializers.UsuarioSerializer import UsuarioSerializer, RolSerializer

class ListaMenuSerializer(serializers.ModelSerializer):
    class Meta:
        model = Menu
        fields = '__all__'

class MenuSerializer(serializers.ModelSerializer):
    cod_usr = UsuarioSerializer(read_only=True)
    cod_menu_padre = ListaMenuSerializer(read_only=True)
    class Meta:
        model = Menu
        fields = '__all__'

class MenuRolSerializer(serializers.ModelSerializer):
    cod_usr = UsuarioSerializer(read_only=True)
    cod_menu = MenuSerializer(read_only=True)
    cod_rol = RolSerializer(read_only=True)
    class Meta:
        model = MenuRol
        fields = '__all__'

class CambiarMenuRolSerializer(serializers.ModelSerializer):
    class Meta:
        model = MenuRol
        fields = '__all__'