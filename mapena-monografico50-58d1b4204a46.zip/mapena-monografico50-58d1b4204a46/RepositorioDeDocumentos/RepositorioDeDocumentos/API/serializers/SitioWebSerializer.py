from dataclasses import fields
from rest_framework import serializers
class SitioWebSerializer(serializers.Serializer):
    class Meta:
       pass
