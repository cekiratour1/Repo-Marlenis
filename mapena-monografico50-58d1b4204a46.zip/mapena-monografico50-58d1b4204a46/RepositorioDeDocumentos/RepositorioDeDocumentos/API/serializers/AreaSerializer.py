from dataclasses import fields
from rest_framework import serializers
from API.models.rd.models import area, facultad, tipoarea
from API.serializers.DashboardSerializer import ListaSerializer, ListaTipoAreaSerializer

class ListaAreaSerializer(serializers.ModelSerializer):
    cod_facultad = ListaSerializer(read_only=True)
    cod_tipoarea = ListaTipoAreaSerializer(read_only=True)
    class Meta:
        model = area
        fields = '__all__'

class AreaCrearSerializer (serializers.ModelSerializer):
    class Meta:
        model= area
        fields = (
            'cod_area',
            'cod_facultad',
            'cod_tipoarea',
            'nom_area',
            'cod_usr',
            'mca_inh',
            'fec_actu'
        )

class TipoAreaSerializer(serializers.ModelSerializer):
    class Meta:
        model = tipoarea
        fields = '__all__'