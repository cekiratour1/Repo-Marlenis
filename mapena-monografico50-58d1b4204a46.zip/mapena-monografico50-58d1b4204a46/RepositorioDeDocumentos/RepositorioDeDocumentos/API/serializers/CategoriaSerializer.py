from dataclasses import fields
from rest_framework import serializers
from API.models.rdcategorias.models import categoria
class CategoriaSerializer(serializers.ModelSerializer):
    class Meta:
        model= categoria
        fields = (
            'cod_categoria',
            'nom_categoria',
            'cod_usr',
            'mca_inh',
            'fec_actu'
            );


