from dataclasses import fields
from rest_framework import serializers
from API.models.rdlibros.models import libro, archivo
from API.models.rd.models import facultad
from API.models.rd.models import area
from API.models.rdcategorias.models import categoria 
from API.serializers.DashboardSerializer import ListaSerializer
from API.serializers.AreaSerializer import AreaCrearSerializer
from API.serializers.CategoriaSerializer import CategoriaSerializer


class ListaArchivoNoBinSerializer (serializers.ModelSerializer):
    class Meta:
        model= archivo
        fields = (
            'cod_archivo',
            'cod_libro',
            'nom_archivo',
            'extension',
            'tip_archivo',
            'cod_usr',
            'fec_actu',
            'mca_inh',
            'fec_crea',
        )
class ArchivoBinSerializer (serializers.ModelSerializer):
    class Meta:
        model= archivo
        fields = (
            'bin_archivo',
        )

class ArchivoCrearSerializer (serializers.ModelSerializer):
    class Meta:
        model= archivo
        fields = (
            'cod_archivo',
            'cod_libro',
            'nom_archivo',
            'extension',
            'tip_archivo',
            'cod_usr',
            'fec_actu',
            'mca_inh',
            'fec_crea',
            'bin_archivo',
        )

class LibroListaSerializer(serializers.ModelSerializer):
    cod_facultad = ListaSerializer(read_only=True)
    cod_area = AreaCrearSerializer(read_only=True)
    archivos = ArchivoCrearSerializer(many=True,read_only=True)
    cod_categoria= CategoriaSerializer(read_only=True)
    class Meta:
        model = libro
        fields = '__all__'

class LibroCrearSerializer (serializers.ModelSerializer):
    class Meta:
        model= libro
        fields = (
            'cod_libro',
            'cod_facultad',
            'cod_area',
            'cod_categoria',
            'autor',
            'titulo',
            'decripcion',
            'anio',
            'estado',
            'cod_usr',
            'fec_actu',
            'mca_inh',
            'bin_img_libro',
        )
