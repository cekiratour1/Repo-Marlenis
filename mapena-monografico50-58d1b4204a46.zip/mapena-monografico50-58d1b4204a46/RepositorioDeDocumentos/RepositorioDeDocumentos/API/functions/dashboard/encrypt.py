class Encrypt():
    byte = [128, 64, 32, 16, 8, 4, 2, 1]

    def toNumber(binary):
        num = 0
        for key in range(len(Encrypt.byte)):
            if binary[key] == '1':
                num = num + Encrypt.byte[key]
        return num

    def toBinary(number):
        binary = ''
        for value in Encrypt.byte:
            if number >= value:
                number = number - value
                binary = binary + '1'
            else:
                binary = binary + '0'
        return binary

    def invertBinary(binary):
        bin = ''
        for bit in binary:
            if bit == '1':
                bin = bin + '0'
            else:
                bin = bin + '1'
        
        return bin

    def text(str):
        encrypt = ''
        for char in str:
            encrypt = encrypt + chr(Encrypt.toNumber(Encrypt.invertBinary(Encrypt.toBinary(ord(char)))))
        return encrypt
