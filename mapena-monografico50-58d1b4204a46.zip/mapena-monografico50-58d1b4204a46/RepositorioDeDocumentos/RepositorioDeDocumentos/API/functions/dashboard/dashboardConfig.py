from django.shortcuts import redirect, render
from API.models.rdmenu.models import MenuRol
from API.models.rdusuario.models import UsuarioRol
from .session import Session

def render_privilege(request, template, data=None):
    usuario_data = Session.get(request, data)
    # buscando roles de usuario
    usuario_roles = UsuarioRol.objects.filter(mca_inh='N', cod_usuario=usuario_data['cod_usuario'])
    rol = []
    # almacenando roles
    for row in usuario_roles:
        rol.append(row.cod_rol.cod_rol)

    if MenuRol.objects.filter(cod_menu__url_menu=request.get_full_path(), cod_rol__in=rol).count() == 0:
        if Session.auth(request):
            return redirect('HomeIndex')
        return redirect('LoginIndex')

    return render(request, template, usuario_data)