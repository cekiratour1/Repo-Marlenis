from API.models.rdmenu.models import Menu, MenuRol

def struct(menu, parent=0, result=[]):
    return {
        'cod_menu': menu.cod_menu,
        'is_main': int(menu.cod_menu_padre == None),
        'parent': parent,
        'name': menu.nombre_menu,
        'url': menu.url_menu,
        'icon': menu.url_icono,
        'children': result
    }

def menu(cod_rol=[]):
    _menu = __menu(cod_rol)
    _result = {}
    for _option in _menu:
        if _menu[_option]['is_main'] == True:
            _result[_option] = _menu[_option]

    return _result

def __menu(cod_rol=[], cod_menu=None):
    menu_option = {}
    if cod_menu == None:
        obj = Menu.objects.all()
    else:
        obj = Menu.objects.filter(cod_menu_padre=cod_menu)
        if obj.count() == 0:
            return None

    for opcion in obj:
        result = __menu(cod_rol, opcion.cod_menu)
        if result != None:
            if len(result) == 0:
                continue
            menu_option[opcion.cod_menu] = struct(opcion, 1, result)
        elif cod_menu != None and MenuRol.objects.filter(cod_menu__cod_menu=opcion.cod_menu, cod_rol__cod_rol__in=cod_rol).count() > 0:
            menu_option[opcion.cod_menu] = struct(opcion)

    return menu_option
