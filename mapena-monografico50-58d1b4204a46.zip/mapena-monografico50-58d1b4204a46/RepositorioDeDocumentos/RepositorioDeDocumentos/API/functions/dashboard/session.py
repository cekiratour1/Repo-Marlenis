from django.shortcuts import render, redirect
from API.functions.dashboard.encrypt import Encrypt
from API.models.rdusuario.models import Usuario
from django.core.exceptions import ObjectDoesNotExist
from API.functions.login.BanUserAccess import BanUserAccess
from API.functions.dashboard.menu import menu
from API.models.rdusuario.models import UsuarioRol
import json

class Session():
    def login(request):
        try:
            if BanUserAccess.access(request.POST['username']) == False:
                return render(
                    request,
                    'login/index.html',
                    {
                        "msj": "Demasiados intentos de inicio de sesión, vuelve más tarde.",
                        "old": {
                            "username": request.POST['username']
                        }
                    }
                )

            usuario = Usuario.objects.get(
                usuario=request.POST['username'],
                contrasena=Encrypt.text(request.POST['password'])
            )

            if usuario.mca_inh == 'S':
                return render(
                    request,
                    'login/index.html',
                    {
                        "msj":"Usuario inhabilitado."
                    }
                )

            # buscando roles de usuario
            usuario_roles = UsuarioRol.objects.filter(mca_inh='N', cod_usuario=usuario.cod_usuario)
            rol = []
            # almacenando roles
            for row in usuario_roles:
                rol.append(row.cod_rol.cod_rol)

            __menu = menu(rol)
            if len(__menu) == 0:
                return render(
                    request,
                    'login/index.html',
                    {
                        "msj": "No hay privilegios asignados."
                    }
                )

            #almacenando datos de usuario en sesión
            request.session['user_data'] = {
                'cod_usuario': usuario.cod_usuario,
                'nombre': usuario.nombre,
                'apellido': usuario.apellido,
                'usuario': usuario.usuario,
                'correo': usuario.correo,
                'menu': json.dumps(__menu)
            }
            BanUserAccess.clear(request.POST['username'])
            return redirect('HomeIndex')

        except ObjectDoesNotExist:
            return render(
                request,
                'login/index.html',
                {
                    "msj":"Usuario y/o contraseña incorrectos.",
                    "old": {
                        "username": request.POST['username']
                    }
                }
            )

    def auth(request):
        try:
            if request.session['user_data']:
                return True
        except:
            return False

    def get(request, data=None):
        user_data = request.session.get('user_data')
        if data == None:
            return user_data
        else:
            user_data.update(data)
            return user_data

    def close(request):
        try:
            if request.session['user_data']:
                del request.session['user_data']
        except:
            pass
        return redirect('LoginIndex')


