import time

class BanUserAccess:
    users = {}
    # 5 intentos
    intent = 5
    # 5 minutos en segundos
    ban_limit = 300

    @staticmethod
    def access(username):
        if BanUserAccess.users.get(username):
            if BanUserAccess.users[username]['intents'] >= BanUserAccess.intent:
                if BanUserAccess.users[username]['ban'] == False:
                    BanUserAccess.users[username]['ban'] = True
                    BanUserAccess.users[username]['next_access'] = time.time() + BanUserAccess.ban_limit
            else:
                BanUserAccess.users[username]['intents'] += 1
        else:
            BanUserAccess.users[username] = {
                'intents': 1,
                'next_access': 0,
                'ban': False
            }

        if BanUserAccess.users[username]['ban'] == True and BanUserAccess.users[username]['next_access'] <= time.time():
            BanUserAccess.users[username]['ban'] = False
            BanUserAccess.users[username]['next_access'] = 0
            BanUserAccess.users[username]['intents'] = 1

        return not BanUserAccess.users[username]['ban']

    @staticmethod
    def clear(username):
        if BanUserAccess.users.get(username):
            del BanUserAccess.users[username]