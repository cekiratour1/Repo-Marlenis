import smtplib
from email.message import EmailMessage
def EnviarMail(
    name,
    email,
    phone,
    msj):
    #creacion de objeto Email   
    message = EmailMessage()
    #Titulo del correo
    title = "Nuevo mensaje de: " + name
    email_subject = title
    #Correo desde donde se enviara
    senderMail = "grupomonografico50@gmail.com"
    #pass del send pass
    mailPass="flfawcujmuvcbuag"
    #Correo donde se recibira 
    receiverMail = "grupomonografico50@gmail.com"
    #Configurando los headers del correo
    message['Subject']= email_subject
    message['From']= senderMail
    message['To']= receiverMail 
    #evaluacion de ida y vuelta
    #configuracion del cuerpo del correo
    message.set_content(
        f"""
Se recibio un nuevo mensaje de: {name}
Cuyos datos son: 
Correo: {email}
Mensaje: {msj}
Telefono: {phone}
        """
        )
    #configuracion del servidor SMTP
    mail_smtp = "smtp.gmail.com"
    server = smtplib.SMTP(mail_smtp,'587')
    #intentamos identificar el cliente con el servidor SMTP
    server.ehlo()
    #Aseguramos la coneccion SMTP
    server.starttls()
    #Logeo del correo
    server.login(senderMail,mailPass)
    #enviamos el correo
    server.send_message(message)
    #siempre cerramos la conexion 
    server.quit()
#pass del correo flfawcujmuvcbuag
EnviarMail('Ander', 'anderson_ortiz05@hotmail.com', '90808', 'prueba numero 9000')