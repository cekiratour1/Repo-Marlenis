from django.urls import path
from sitioweb import views

urlpatterns = [
    path('', views.mostrarPaginaPrincipal, name='sitioweb'),
    path('documentos', views.mostrarPaginasDocumentos, name='documento'),
    path('detallepublicacion/<id>', views.mostrarDetallePublicacion, name='detallePublicacion'),
]
