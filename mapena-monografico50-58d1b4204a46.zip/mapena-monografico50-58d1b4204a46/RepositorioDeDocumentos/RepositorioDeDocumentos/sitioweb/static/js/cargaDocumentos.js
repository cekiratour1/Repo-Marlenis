$(document).ready(() => {
    startLoading();

    setTimeout(() => {
        cargaLibrosInicial();
    }, 50);

});

function cargaLibrosInicial() {
    const listaLibros = ejecutarAjax('API/libroslist/librosporfiltro', 'GET', null);
    endLoading();
    let cards = "";

    if (listaLibros.length > 0) {
        cards = cardBuilder(listaLibros);
    } else {
        cards = `<div class="card-fetched card-container p-3"><p>No se han encontrado resultados con el criterio de búsqueda dado.</p></div>`;
    }
    $(".articulosContainer").append(cards);

    return true;

}

$('#btn-busqueda').click((e) => {

    startLoading();

    setTimeout(() => {
        fetchBooks();
    }, 500)
});
$('#btnLimpiar').click((e) => {

    startLoading();

    setTimeout(() => {
        location.href = '/documentos';
    }, 500)
});
//

function fetchBooks() {

    $(".card-fetched").remove();

    var facultadDropdown = $("#facultad").val();
    var categoriaDropdown = $("#categoria").val();
    var areaDropdown = $("#area").val();
    var criterioBusqueda = $("#criterioBusqueda").val();

    //busqueda a db
    const baseQuery = "/API/libroslist/librosporfiltro";

    let query = `${baseQuery}?`;

    if (facultadDropdown !== "")
        query += `fc=${facultadDropdown}`;

    if (areaDropdown !== "")
        query += `&ar=${areaDropdown}`

    if (categoriaDropdown !== "")
        query += `&cat=${categoriaDropdown}`

    if (criterioBusqueda !== "")
        query += `&cr=${criterioBusqueda}`

    const cartasFiltradas = ejecutarAjax(query, 'GET', null);

    let cards = "";

    if (cartasFiltradas.length > 0) {
        cards = cardBuilder(cartasFiltradas);
    } else {
        cards = `<div class="card-container card-fetched p-3"><p>No se han encontrado resultados con el criterio de búsqueda dado.</p></div>`
    }

    $(".articulosContainer").append(cards);

    endLoading();
    return true;
}



function cardBuilder(listaLibros) {

    let cards = "";

    for (var i = 0; i < listaLibros.length; i++) {
        let imglibro = listaLibros[i].bin_img_libro != null ? listaLibros[i].bin_img_libro : "../static/assets/img/Sinimagen.gif";
        cards += `
                <a class="card-fetched" href='detallepublicacion/${listaLibros[i].cod_libro}' style='text-decoration: none;'>
                      <div class="card-container">
                      <div class="cardTailwind">
                          <img class="cardImage" src="${imglibro}" alt="imagen">
                          <div class="flex flex-col justify-between p-4 leading-normal">
                              <h5 style="margin-bottom: 0.5rem; color: #111827; font-size: 1.5rem; line-height: 2rem; font-weight: 700; letter-spacing: -0.025em; ">
                                ${listaLibros[i].titulo}
                              </h5>
                              <div style="margin-bottom: 5px;">
                                  <span class="badge-category">${listaLibros[i].cod_facultad.nombre}</span>
                                  <span class="badge-category">${listaLibros[i].cod_area.nom_area}</span>
                              </div>
                              <p style="margin-bottom: 0.75rem; color: #374151; font-weight: 400; ">${listaLibros[i].decripcion}.</p>
                              <p style="margin-bottom: -1px; color: #374151; font-weight: 400; "><strong>Autor: </strong>${listaLibros[i].autor}</p>
                              <p style="margin-bottom: 5px; color: #374151; font-weight: 400; "><strong>Año: </strong>${listaLibros[i].anio}</p>
                          </div>
                      </div>
                  </div>
                </a>
                 `;
    }

    return cards;

}

/**
 * LIBRO RESPONSE
 * 
 * {
    "cod_libro": 1,
    "cod_facultad": {
        "cod_facultad": 1,
        "nombre": "Facultad de Ciencias"
    },
    "cod_area": {
        "cod_area": 2,
        "cod_facultad": 1,
        "nom_area": "Informatica",
        "cod_usr": 1,
        "mca_inh": "N",
        "fec_actu": "2022-11-29"
    },
    "autor": "Prueba Autor",
    "titulo": "Esta es una prueba acualizando",
    "anio": 2006,
    "estado": "P",
    "cod_usr": 10,
    "fec_actu": "2022-12-01",
    "mca_inh": "N",
    "fec_crea": "2022-11-30"
}
 * */
