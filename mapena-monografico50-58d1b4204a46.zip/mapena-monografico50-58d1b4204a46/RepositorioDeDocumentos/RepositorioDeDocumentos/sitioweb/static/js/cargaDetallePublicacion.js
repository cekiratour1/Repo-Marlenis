var libro;
var clibro;
$(document).ready(() => {
    cargaDetallePublicacion();
});

function cargaDetallePublicacion() {
    libro = ejecutarAjax(`/API/libroslist/${getDocumentId()}`, 'GET', null);

    if (libro == undefined) {
        window.href.location('/');
    }

    clibro = libro.cod_libro;
    mapLibroToView(libro);
    return;

}

function mapLibroToView(libro) {
    //portada
    $("[id$='portada']").attr('src', libro.bin_img_libro == null ? "../static/assets/img/Sinimagen.gif" : libro.bin_img_libro); 
    //titulo
    $("#titulo").text(libro.titulo);
    //descripcion
    $("#descripcion").text(libro.decripcion);
    //anio
    $("#anio").text(libro.anio);
    //autor
    $("#autor").text(libro.autor);
    //facultad
    $("#facultad").text(libro.cod_facultad.nombre);
    //area
    $("#area").text(libro.cod_area.nom_area);
    //categoria
    $("#categoria").text(libro.cod_categoria.nom_categoria);

}

function getDocumentId() {

    let id;

    id = window.location.href.split('/');
    return id[id.length - 1];
}
function descargarArchivo() {

    var seleccionado = false;

    for (var i = 0; i < document.formatosArchivo.radioFormatosArchivos.length; i++) {
        if (document.formatosArchivo.radioFormatosArchivos[i].checked) {
            const dlibro = ejecutarAjax(`/API/libroarchivos/descargaarchivo?clibro=${clibro}&ctipo=${document.formatosArchivo.radioFormatosArchivos[i].value}`, 'GET', null);
         
            if (dlibro.length < 1) {
                MuestraMensage('error', "No existe el formato solicitado.");
                return false;
            }
            var a = document.createElement("a"); //Create <a>
            a.href = dlibro[0].bin_archivo;
            a.download = libro.titulo + "." + document.formatosArchivo.radioFormatosArchivos[i].value; //File name Here
            a.click(); //Downloaded file
            seleccionado = true;
        }
    }

    if (seleccionado === false) {
        MuestraMensage('error', "Debe seleccionar una opci�n");
       
    }
}
/**
* LIBRO RESPONSE
* 
*
 * {
    "cod_libro": 1,
    "cod_facultad": {
        "cod_facultad": 1,
        "nombre": "Facultad de Ciencias"
    },
    "cod_area": {
        "cod_area": 1,
        "cod_facultad": 1,
        "cod_tipoarea": 2,
        "nom_area": "Quimica",
        "cod_usr": 10,
        "mca_inh": "N",
        "fec_actu": "2022-12-01"
    },
    "autor": "Anderson",
    "titulo": "Subio su monografico",
    "decripcion": "Prueba de categoria y descripcion",
    "anio": 2000,
    "estado": "A",
    "cod_usr": 10,
    "fec_actu": "2022-12-08",
    "mca_inh": "N",
    "fec_crea": "2022-12-07",
    "cod_categoria": 16
}
* */
