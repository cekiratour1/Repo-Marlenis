$(document).ready(() => {

    cargaCategorias();
    cargaFacultades();
    $('#area').append('<option value="">Seleccione...</option>');

    $("#facultad").on('change', function () {
        cargaAreas($(this).val());
    });

});

function cargaFacultades() {
    var response = ejecutarAjax('/API/listfacultad/', 'GET', null);
    var $select = $('#facultad');
    $select.append('<option value="">Seleccione...</option>');
    $.each(response, function (id, name) {
        $select.append('<option value=' + name.cod_facultad + '>' + name.nombre + '</option>');
    });
}
function cargaAreas(cod_facultad) {
    var response = ejecutarAjax('/API/areas/', 'GET', null);
    var responseFilter = [];
    response.filter(function (item) {
        if (item.cod_facultad == cod_facultad) {
            responseFilter.push(item);
            return;
        }
    });
    var $select = $('#area');
    $select.empty();

    $select.append('<option value="">Seleccione...</option>');
    $.each(responseFilter, function (id, name) {
        $select.append('<option value=' + name.cod_area + '>' + name.nom_area + '</option>');
    });
}

function cargaCategorias() {
    
    var response = ejecutarAjax('/API/categorias/', 'GET', null);

    let $select = $("#categoria");
    $select.append('<option value="">Seleccione...</option>');
    $.each(response, function (id, name) {
        $select.append('<option value=' + name.cod_categoria + '>' + name.nom_categoria + '</option>');
    });

}