function ejecutarAjax(endPoint, type, body) {
    /*
        JSON.stringify({
            'obj': objparam
        })
    */

    var json = (body != null ? JSON.stringify(body) : body);
    var response = null;
    $.ajax({
        type: type,
        url: endPoint,
        data: json,

        //dataType: 'json', /676/ dataType is json format
        contentType: "application/json; charset=utf-8",
        success: function (resultado) {
            //-------------------------
            response = resultado;
        },
        error: function (err) {
            console.log('Ocurrio un error: ' + err)
            console.error(err.responseText);
        },
        async: false
    });
    return response;
}

/*Limpia el div seleccionado. mp(MP)*/
function limpiarCampos(objeto) {
    var continua = true;
    $('#' + objeto).find('input, select, textarea', 'text')
        .each(function (i, control) {
            if(control.id.length > 0){
                var a = $("#" + control.id).val('');
                if (!a)
                    continua = a;
            }
        });
    return continua;
}

//Valida solamente el div seleccionado. mp
function validarDiv(div) {
    var divCampos = $("#" + div).children();
    var continua = true;
    for (i = 0; i < divCampos.length; i++) {
        var c1 = divCampos.children(i).children();

        for (ii = 0; ii < c1.length; ii++) {
            var c = c1.children(ii);
            for (j = 0; j < c.length; j++) {

                if (c[j].nodeName === 'SELECT' || c[j].nodeName === 'INPUT') {
                    var a = $("#" + c[j].id).validationEngine('validate');
                    if (!a)
                        continua = a;
                }
            }
        }
    }
    //$(divCampos).find('input, select, textarea').each(function () {
    //    var a = $("#" + c[j].id).validationEngine('validate');
    //    if (!a)
    //        continua = a;
    //});
    return continua;

}

// constante para encriptar la contrase�a
const Encrypt = {
    bytes: [128, 64, 32, 16, 8, 4, 2, 1],
    toBinary: (ascii) => {
        let binary = ''
        for (byte of Encrypt.bytes) {
            binary += ascii >= byte ? 1 : 0
            ascii -= ascii >= byte ? byte : 0
        }
        return binary
    },
    invertBinary: (binary) => {
        let newBin = ''
        for (bin of binary) {
            newBin += bin === '1' ? '0' : '1'
        }
        return newBin
    },
    toNumber: (binary) => {
        let ascii = 0
        for (key in Encrypt.bytes) {
            ascii += binary[key] == '1' ? Encrypt.bytes[key] : 0
        }
        return ascii
    },
    text: (str) => {
        var ascii_val = []
        for (chr of str) {
            let ascii = Encrypt.toNumber(Encrypt.invertBinary(Encrypt.toBinary(chr.charCodeAt(0))))
            ascii_val.push(ascii)
        }
        return String.fromCharCode(...ascii_val)
    }
};

//Llena tabla
function cargaTabla(idTabla, resultSet, columns, columnsSize) {
    var cols = [];
    var colsSize = [];
    columns.forEach((element, index) => {
        var dd = new Object();
        dd.data = element;
        cols[index] = dd;
    });
    if (columnsSize != null)
        columnsSize.forEach((element, index) => {
            var d = new Object();
            d.width = element + "px";
            d.targets = index;
            colsSize[index] = d;
        });

    var botones = new Object();
    botones.defaultContent = '<img src="../../static/img/icons/edit.png" id="edit" style="cursor:pointer;margin-right:25px" />' +
        '<img src="../../static/img/icons/delete.png" id="delete" style="cursor:pointer" />';
    cols[cols.length] = botones;

    var jsonColumns = (cols != null ? JSON.stringify(cols) : cols);
    var jsonColumnsSizes = (colsSize != null ? JSON.stringify(colsSize) : colsSize);

    var table = $('#' + idTabla).DataTable({
        responsive: true,
        paging: true,
        searching: true,
        destroy: true,
        "aaData": resultSet,
        "columns": cols,
        "columnDefs": (colsSize != null ? colsSize : []),
        "language": {
            "zeroRecords": "No se encontraron coincidencias",
            "emptyTable": "No hay datos disponibles",
            "search": "<span>Buscar:</span>",
            "paginate": {
                "first": "Primero",
                "previous": "Anterior",
                "next": "Siguiente",
                "last": "Último"

            },
            "info": "Viendo _PAGE_ de _PAGES_",
            "infoEmpty": "No hay registros disponibles.",
            "infoFiltered": "(filtrados desde _MAX_ total de registros)",
            "lengthMenu": "Ver _MENU_ registros por pagina",
            "scrollX": true
        }
    });
    return table;

}

//subo el cargando de la pagina MP.
function startLoading() {
    $('#preloader').fadeIn('slow');
    $('#overlay').fadeIn('slow');
}
//quito el cargando de la pagina MP.
function endLoading() {
    $('#preloader').delay(100).fadeOut(300);
    $('#overlay').delay(100).fadeOut(300);
}
