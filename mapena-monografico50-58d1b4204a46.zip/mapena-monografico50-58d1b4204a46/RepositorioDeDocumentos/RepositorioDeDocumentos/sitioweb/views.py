from django.shortcuts import render
from API.views import Send_mail
from django.shortcuts import redirect
# Create your views here.

def mostrarPaginaPrincipal(request):
    if request.method == 'GET':
        return render(request, "index.html")
    else:
        Send_mail(request)    
        #return redirect('sitioweb')
        return render(request,"index.html",{
        "msj":"Correo enviado correctamente"
        })

def mostrarPaginasDocumentos(request):
    return render(request, "filtro.html")

def mostrarDetallePublicacion(request, id):
    return render(request, "detallepublicacion.html",{
        "id": id
        })
