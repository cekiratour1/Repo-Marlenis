"""
fro m user.models import User
from django.contrib.auth.hashers import make_password

def auth(request):
    try:
        data = User.objects.get(username=request.POST['username'], password=make_password(request.POST['password']), status='active')
        request.session['user_data'] = data
        return True
    except:
        return False
""" 